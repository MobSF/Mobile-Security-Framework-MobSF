//
//  User+CoreDataClass.swift
//  
//
//  Created by Prateek Gianchandani on 14/12/17.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
