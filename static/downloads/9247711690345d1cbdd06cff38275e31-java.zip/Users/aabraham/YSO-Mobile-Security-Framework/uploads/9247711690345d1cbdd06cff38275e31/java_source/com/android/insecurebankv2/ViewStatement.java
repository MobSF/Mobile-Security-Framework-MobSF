package com.android.insecurebankv2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class ViewStatement
  extends Activity
{
  String uname;
  
  public ViewStatement() {}
  
  public void callPreferences()
  {
    startActivity(new Intent(this, FilePrefActivity.class));
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903070);
    uname = getIntent().getStringExtra("uname");
    WebView localWebView = (WebView)findViewById(2131034199);
    localWebView.loadUrl("file://" + Environment.getExternalStorageDirectory() + "/Statements_" + uname + ".html");
    localWebView.getSettings().setJavaScriptEnabled(true);
    localWebView.getSettings().setSaveFormData(true);
    localWebView.getSettings().setBuiltInZoomControls(true);
    localWebView.setWebViewClient(new MyWebViewClient());
    localWebView.setWebChromeClient(new WebChromeClient());
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131492866, paramMenu);
    return true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    int i = paramMenuItem.getItemId();
    if (i == 2131034200)
    {
      callPreferences();
      return true;
    }
    if (i == 2131034201)
    {
      Intent localIntent = new Intent(getBaseContext(), LoginActivity.class);
      localIntent.addFlags(67108864);
      startActivity(localIntent);
      return true;
    }
    return super.onOptionsItemSelected(paramMenuItem);
  }
}
