package android.support.v7.app;

import android.app.Activity;

public class ActionBarImplJB
  extends ActionBarImplICS
{
  public ActionBarImplJB(Activity paramActivity, ActionBar.Callback paramCallback)
  {
    super(paramActivity, paramCallback, false);
  }
}
