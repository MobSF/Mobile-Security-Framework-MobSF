package com.android.insecurebankv2;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

public class ChangePassword
  extends Activity
{
  private static final String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
  Button changePassword_button;
  EditText changePassword_text;
  private Matcher matcher;
  private Pattern pattern;
  String protocol = "http://";
  BufferedReader reader;
  String result;
  String serverip = "";
  String serverport = "";
  TextView textView_Username;
  String uname;
  
  public ChangePassword() {}
  
  public void callPreferences()
  {
    startActivity(new Intent(this, FilePrefActivity.class));
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903064);
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
    serverip = localSharedPreferences.getString("serverip", null);
    serverport = localSharedPreferences.getString("serverport", null);
    changePassword_text = ((EditText)findViewById(2131034174));
    uname = getIntent().getStringExtra("uname");
    System.out.println("newpassword=" + uname);
    textView_Username = ((TextView)findViewById(2131034172));
    textView_Username.setText(uname);
    changePassword_button = ((Button)findViewById(2131034176));
    changePassword_button.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        ChangePassword.RequestChangePasswordTask localRequestChangePasswordTask = new ChangePassword.RequestChangePasswordTask(ChangePassword.this);
        String[] arrayOfString = new String[1];
        arrayOfString[0] = uname;
        localRequestChangePasswordTask.execute(arrayOfString);
      }
    });
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131492866, paramMenu);
    return true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    int i = paramMenuItem.getItemId();
    if (i == 2131034200)
    {
      callPreferences();
      return true;
    }
    if (i == 2131034201)
    {
      Intent localIntent = new Intent(getBaseContext(), LoginActivity.class);
      localIntent.addFlags(67108864);
      startActivity(localIntent);
      return true;
    }
    return super.onOptionsItemSelected(paramMenuItem);
  }
  
  class RequestChangePasswordTask
    extends AsyncTask<String, String, String>
  {
    RequestChangePasswordTask() {}
    
    private String convertStreamToString(InputStream paramInputStream)
      throws IOException
    {
      try
      {
        reader = new BufferedReader(new InputStreamReader(paramInputStream, "UTF-8"));
        localStringBuilder = new StringBuilder();
        str = reader.readLine();
        if (str == null)
        {
          paramInputStream.close();
          return localStringBuilder.toString();
        }
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        for (;;)
        {
          StringBuilder localStringBuilder;
          String str;
          localUnsupportedEncodingException.printStackTrace();
          continue;
          localStringBuilder.append(str + "\n");
        }
      }
    }
    
    protected String doInBackground(String... paramVarArgs)
    {
      try
      {
        postData(paramVarArgs[0]);
        return null;
      }
      catch (BadPaddingException localBadPaddingException)
      {
        for (;;)
        {
          localBadPaddingException.printStackTrace();
        }
      }
      catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
      {
        for (;;) {}
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
        for (;;) {}
      }
      catch (JSONException localJSONException)
      {
        for (;;) {}
      }
      catch (NoSuchPaddingException localNoSuchPaddingException)
      {
        for (;;) {}
      }
      catch (IOException localIOException)
      {
        for (;;) {}
      }
      catch (InvalidKeyException localInvalidKeyException)
      {
        for (;;) {}
      }
      catch (IllegalBlockSizeException localIllegalBlockSizeException)
      {
        for (;;) {}
      }
    }
    
    protected void onPostExecute(Double paramDouble) {}
    
    protected void onProgressUpdate(Integer... paramVarArgs) {}
    
    public void postData(String paramString)
      throws ClientProtocolException, IOException, JSONException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException
    {
      DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient();
      HttpPost localHttpPost = new HttpPost(protocol + serverip + ":" + serverport + "/changepassword");
      ArrayList localArrayList = new ArrayList(2);
      localArrayList.add(new BasicNameValuePair("username", uname));
      localArrayList.add(new BasicNameValuePair("newpassword", changePassword_text.getText().toString()));
      localHttpPost.setEntity(new UrlEncodedFormEntity(localArrayList));
      pattern = Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})");
      matcher = pattern.matcher(changePassword_text.getText().toString());
      if (matcher.matches())
      {
        InputStream localInputStream = localDefaultHttpClient.execute(localHttpPost).getEntity().getContent();
        result = convertStreamToString(localInputStream);
        result = result.replace("\n", "");
        runOnUiThread(new Runnable()
        {
          public void run()
          {
            if ((result != null) && (result.indexOf("Change Password Successful") != -1)) {}
            try
            {
              String str = new JSONObject(result).getString("message");
              Toast.makeText(getApplicationContext(), str + ". Restart application to Continue.", 1).show();
              return;
            }
            catch (JSONException localJSONException)
            {
              localJSONException.printStackTrace();
            }
          }
        });
        return;
      }
      runOnUiThread(new Runnable()
      {
        public void run()
        {
          Toast.makeText(getApplicationContext(), "Entered password is not complex enough.", 1).show();
        }
      });
    }
  }
}
