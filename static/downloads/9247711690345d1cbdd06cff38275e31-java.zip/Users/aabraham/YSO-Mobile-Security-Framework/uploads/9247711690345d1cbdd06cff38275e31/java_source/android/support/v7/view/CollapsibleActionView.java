package android.support.v7.view;

public abstract interface CollapsibleActionView
{
  public abstract void onActionViewCollapsed();
  
  public abstract void onActionViewExpanded();
}
