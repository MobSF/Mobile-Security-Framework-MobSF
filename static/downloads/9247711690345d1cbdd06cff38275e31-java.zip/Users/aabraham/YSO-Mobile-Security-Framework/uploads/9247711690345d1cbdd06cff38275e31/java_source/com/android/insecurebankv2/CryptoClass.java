package com.android.insecurebankv2;

import android.util.Base64;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptoClass
{
  String base64Text;
  byte[] cipherData;
  String cipherText;
  byte[] ivBytes = new byte[16];
  String key = "This is the super secret key 123";
  String plainText;
  
  public CryptoClass() {}
  
  public static byte[] aes256decrypt(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
    throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException
  {
    IvParameterSpec localIvParameterSpec = new IvParameterSpec(paramArrayOfByte1);
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte2, "AES");
    Cipher localCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
    localCipher.init(2, localSecretKeySpec, localIvParameterSpec);
    return localCipher.doFinal(paramArrayOfByte3);
  }
  
  public static byte[] aes256encrypt(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
    throws UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException
  {
    IvParameterSpec localIvParameterSpec = new IvParameterSpec(paramArrayOfByte1);
    SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramArrayOfByte2, "AES");
    Cipher localCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
    localCipher.init(1, localSecretKeySpec, localIvParameterSpec);
    return localCipher.doFinal(paramArrayOfByte3);
  }
  
  public String aesDeccryptedString(String paramString)
    throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException
  {
    byte[] arrayOfByte = key.getBytes("UTF-8");
    cipherData = aes256decrypt(ivBytes, arrayOfByte, Base64.decode(paramString.getBytes("UTF-8"), 0));
    plainText = new String(cipherData, "UTF-8");
    return plainText;
  }
  
  public String aesEncryptedString(String paramString)
    throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException
  {
    byte[] arrayOfByte = key.getBytes("UTF-8");
    plainText = paramString;
    cipherData = aes256encrypt(ivBytes, arrayOfByte, plainText.getBytes("UTF-8"));
    cipherText = Base64.encodeToString(cipherData, 0);
    return cipherText;
  }
}
