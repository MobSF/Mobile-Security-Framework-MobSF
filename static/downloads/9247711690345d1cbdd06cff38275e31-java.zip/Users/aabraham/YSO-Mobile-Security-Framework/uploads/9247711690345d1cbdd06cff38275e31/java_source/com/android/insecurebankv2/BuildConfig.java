package com.android.insecurebankv2;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
  
  public BuildConfig() {}
}
