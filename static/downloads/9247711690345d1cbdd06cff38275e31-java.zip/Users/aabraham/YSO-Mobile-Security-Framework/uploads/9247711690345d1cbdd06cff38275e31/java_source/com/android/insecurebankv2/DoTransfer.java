package com.android.insecurebankv2;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

public class DoTransfer
  extends Activity
{
  public static final String MYPREFS2 = "mySharedPreferences";
  String acc1;
  String acc2;
  EditText amount;
  Button button1;
  EditText ed1;
  TextView fr;
  EditText from;
  Button getAccounts;
  InputStream in;
  JSONObject jsonObject;
  String number = "1234";
  String passBase64String;
  String passNormalized;
  EditText phoneNumber;
  String protocol = "http://";
  BufferedReader reader;
  HttpResponse responseBody;
  String result;
  String result2;
  String serverip = "";
  String serverport = "";
  EditText to;
  Button transfer;
  EditText trf_from;
  String trf_password = null;
  EditText trf_to;
  String trf_username = null;
  TextView tv1;
  String usernameBase64ByteString;
  BufferedWriter wr = null;
  
  public DoTransfer() {}
  
  private String getNormalizedPassword(String paramString)
    throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException
  {
    return new CryptoClass().aesDeccryptedString(paramString);
  }
  
  public void callPreferences()
  {
    startActivity(new Intent(this, FilePrefActivity.class));
  }
  
  public String convertStreamToString(InputStream paramInputStream)
    throws IOException
  {
    try
    {
      reader = new BufferedReader(new InputStreamReader(paramInputStream, "UTF-8"));
      localStringBuilder = new StringBuilder();
      str = reader.readLine();
      if (str == null)
      {
        paramInputStream.close();
        return localStringBuilder.toString();
      }
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      for (;;)
      {
        StringBuilder localStringBuilder;
        String str;
        localUnsupportedEncodingException.printStackTrace();
        continue;
        localStringBuilder.append(str + "\n");
      }
    }
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903066);
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
    serverip = localSharedPreferences.getString("serverip", null);
    serverport = localSharedPreferences.getString("serverport", null);
    transfer = ((Button)findViewById(2131034183));
    transfer.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        from = ((EditText)findViewById(2131034180));
        to = ((EditText)findViewById(2131034178));
        new DoTransfer.RequestDoTransferTask(DoTransfer.this).execute(new String[] { "username" });
      }
    });
    button1 = ((Button)findViewById(2131034181));
    button1.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        new DoTransfer.RequestDoGets2(DoTransfer.this).execute(new String[] { "username" });
      }
    });
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131492866, paramMenu);
    return true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    int i = paramMenuItem.getItemId();
    if (i == 2131034200)
    {
      callPreferences();
      return true;
    }
    if (i == 2131034201)
    {
      Intent localIntent = new Intent(getBaseContext(), LoginActivity.class);
      localIntent.addFlags(67108864);
      startActivity(localIntent);
      return true;
    }
    return super.onOptionsItemSelected(paramMenuItem);
  }
  
  public class RequestDoGets2
    extends AsyncTask<String, String, String>
  {
    public RequestDoGets2() {}
    
    public void AsyncHttpPost(String paramString) {}
    
    /* Error */
    public String doInBackground(String... paramVarArgs)
    {
      // Byte code:
      //   0: new 47	org/apache/http/impl/client/DefaultHttpClient
      //   3: dup
      //   4: invokespecial 48	org/apache/http/impl/client/DefaultHttpClient:<init>	()V
      //   7: astore_2
      //   8: new 50	org/apache/http/client/methods/HttpPost
      //   11: dup
      //   12: new 52	java/lang/StringBuilder
      //   15: dup
      //   16: aload_0
      //   17: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   20: getfield 58	com/android/insecurebankv2/DoTransfer:protocol	Ljava/lang/String;
      //   23: invokestatic 64	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
      //   26: invokespecial 66	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   29: aload_0
      //   30: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   33: getfield 69	com/android/insecurebankv2/DoTransfer:serverip	Ljava/lang/String;
      //   36: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   39: ldc 75
      //   41: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   44: aload_0
      //   45: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   48: getfield 78	com/android/insecurebankv2/DoTransfer:serverport	Ljava/lang/String;
      //   51: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   54: ldc 80
      //   56: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   59: invokevirtual 84	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   62: invokespecial 85	org/apache/http/client/methods/HttpPost:<init>	(Ljava/lang/String;)V
      //   65: astore_3
      //   66: aload_0
      //   67: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   70: ldc 87
      //   72: iconst_0
      //   73: invokevirtual 91	com/android/insecurebankv2/DoTransfer:getSharedPreferences	(Ljava/lang/String;I)Landroid/content/SharedPreferences;
      //   76: astore 4
      //   78: aload 4
      //   80: ldc 93
      //   82: aconst_null
      //   83: invokeinterface 99 3 0
      //   88: iconst_0
      //   89: invokestatic 105	android/util/Base64:decode	(Ljava/lang/String;I)[B
      //   92: astore 5
      //   94: aload_0
      //   95: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   98: new 60	java/lang/String
      //   101: dup
      //   102: aload 5
      //   104: ldc 107
      //   106: invokespecial 110	java/lang/String:<init>	([BLjava/lang/String;)V
      //   109: putfield 113	com/android/insecurebankv2/DoTransfer:usernameBase64ByteString	Ljava/lang/String;
      //   112: aload 4
      //   114: ldc 115
      //   116: aconst_null
      //   117: invokeinterface 99 3 0
      //   122: astore 7
      //   124: aload_0
      //   125: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   128: aload_0
      //   129: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   132: aload 7
      //   134: invokestatic 119	com/android/insecurebankv2/DoTransfer:access$0	(Lcom/android/insecurebankv2/DoTransfer;Ljava/lang/String;)Ljava/lang/String;
      //   137: putfield 122	com/android/insecurebankv2/DoTransfer:passNormalized	Ljava/lang/String;
      //   140: new 124	java/util/ArrayList
      //   143: dup
      //   144: iconst_2
      //   145: invokespecial 127	java/util/ArrayList:<init>	(I)V
      //   148: astore 9
      //   150: aload 9
      //   152: new 129	org/apache/http/message/BasicNameValuePair
      //   155: dup
      //   156: ldc -125
      //   158: aload_0
      //   159: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   162: getfield 113	com/android/insecurebankv2/DoTransfer:usernameBase64ByteString	Ljava/lang/String;
      //   165: invokespecial 134	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
      //   168: invokeinterface 140 2 0
      //   173: pop
      //   174: aload 9
      //   176: new 129	org/apache/http/message/BasicNameValuePair
      //   179: dup
      //   180: ldc -114
      //   182: aload_0
      //   183: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   186: getfield 122	com/android/insecurebankv2/DoTransfer:passNormalized	Ljava/lang/String;
      //   189: invokespecial 134	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
      //   192: invokeinterface 140 2 0
      //   197: pop
      //   198: aload_3
      //   199: new 144	org/apache/http/client/entity/UrlEncodedFormEntity
      //   202: dup
      //   203: aload 9
      //   205: invokespecial 147	org/apache/http/client/entity/UrlEncodedFormEntity:<init>	(Ljava/util/List;)V
      //   208: invokevirtual 151	org/apache/http/client/methods/HttpPost:setEntity	(Lorg/apache/http/HttpEntity;)V
      //   211: aload_0
      //   212: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   215: aload_2
      //   216: aload_3
      //   217: invokeinterface 157 2 0
      //   222: putfield 161	com/android/insecurebankv2/DoTransfer:responseBody	Lorg/apache/http/HttpResponse;
      //   225: aload_0
      //   226: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   229: aload_0
      //   230: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   233: getfield 161	com/android/insecurebankv2/DoTransfer:responseBody	Lorg/apache/http/HttpResponse;
      //   236: invokeinterface 167 1 0
      //   241: invokeinterface 173 1 0
      //   246: putfield 177	com/android/insecurebankv2/DoTransfer:in	Ljava/io/InputStream;
      //   249: aload_0
      //   250: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   253: aload_0
      //   254: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   257: aload_0
      //   258: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   261: getfield 177	com/android/insecurebankv2/DoTransfer:in	Ljava/io/InputStream;
      //   264: invokevirtual 181	com/android/insecurebankv2/DoTransfer:convertStreamToString	(Ljava/io/InputStream;)Ljava/lang/String;
      //   267: putfield 184	com/android/insecurebankv2/DoTransfer:result	Ljava/lang/String;
      //   270: aload_0
      //   271: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   274: aload_0
      //   275: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   278: getfield 184	com/android/insecurebankv2/DoTransfer:result	Ljava/lang/String;
      //   281: ldc -70
      //   283: ldc -68
      //   285: invokevirtual 192	java/lang/String:replace	(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
      //   288: putfield 184	com/android/insecurebankv2/DoTransfer:result	Ljava/lang/String;
      //   291: aload_0
      //   292: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   295: getfield 184	com/android/insecurebankv2/DoTransfer:result	Ljava/lang/String;
      //   298: ifnull +78 -> 376
      //   301: aload_0
      //   302: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   305: getfield 184	com/android/insecurebankv2/DoTransfer:result	Ljava/lang/String;
      //   308: ldc -62
      //   310: invokevirtual 198	java/lang/String:indexOf	(Ljava/lang/String;)I
      //   313: iconst_m1
      //   314: if_icmpeq +62 -> 376
      //   317: aload_0
      //   318: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   321: new 200	org/json/JSONObject
      //   324: dup
      //   325: aload_0
      //   326: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   329: getfield 184	com/android/insecurebankv2/DoTransfer:result	Ljava/lang/String;
      //   332: invokespecial 201	org/json/JSONObject:<init>	(Ljava/lang/String;)V
      //   335: putfield 205	com/android/insecurebankv2/DoTransfer:jsonObject	Lorg/json/JSONObject;
      //   338: aload_0
      //   339: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   342: aload_0
      //   343: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   346: getfield 205	com/android/insecurebankv2/DoTransfer:jsonObject	Lorg/json/JSONObject;
      //   349: ldc -49
      //   351: invokevirtual 210	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
      //   354: putfield 213	com/android/insecurebankv2/DoTransfer:acc1	Ljava/lang/String;
      //   357: aload_0
      //   358: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   361: aload_0
      //   362: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   365: getfield 205	com/android/insecurebankv2/DoTransfer:jsonObject	Lorg/json/JSONObject;
      //   368: ldc -41
      //   370: invokevirtual 210	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
      //   373: putfield 218	com/android/insecurebankv2/DoTransfer:acc2	Ljava/lang/String;
      //   376: aload_0
      //   377: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoGets2:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   380: new 220	com/android/insecurebankv2/DoTransfer$RequestDoGets2$1
      //   383: dup
      //   384: aload_0
      //   385: invokespecial 223	com/android/insecurebankv2/DoTransfer$RequestDoGets2$1:<init>	(Lcom/android/insecurebankv2/DoTransfer$RequestDoGets2;)V
      //   388: invokevirtual 227	com/android/insecurebankv2/DoTransfer:runOnUiThread	(Ljava/lang/Runnable;)V
      //   391: ldc -27
      //   393: areturn
      //   394: astore 6
      //   396: aload 6
      //   398: invokevirtual 232	java/io/UnsupportedEncodingException:printStackTrace	()V
      //   401: goto -289 -> 112
      //   404: astore 8
      //   406: aload 8
      //   408: invokevirtual 235	java/lang/Exception:printStackTrace	()V
      //   411: goto -271 -> 140
      //   414: astore 12
      //   416: aload 12
      //   418: invokevirtual 232	java/io/UnsupportedEncodingException:printStackTrace	()V
      //   421: goto -210 -> 211
      //   424: astore 13
      //   426: aload 13
      //   428: invokevirtual 236	java/io/IOException:printStackTrace	()V
      //   431: goto -206 -> 225
      //   434: astore 14
      //   436: aload 14
      //   438: invokevirtual 235	java/lang/Exception:printStackTrace	()V
      //   441: goto -192 -> 249
      //   444: astore 15
      //   446: aload 15
      //   448: invokevirtual 236	java/io/IOException:printStackTrace	()V
      //   451: goto -181 -> 270
      //   454: astore 16
      //   456: aload 16
      //   458: invokevirtual 237	org/json/JSONException:printStackTrace	()V
      //   461: goto -85 -> 376
      //   464: astore 14
      //   466: goto -30 -> 436
      //   469: astore 8
      //   471: goto -65 -> 406
      //   474: astore 8
      //   476: goto -70 -> 406
      //   479: astore 8
      //   481: goto -75 -> 406
      //   484: astore 8
      //   486: goto -80 -> 406
      //   489: astore 8
      //   491: goto -85 -> 406
      //   494: astore 8
      //   496: goto -90 -> 406
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	499	0	this	RequestDoGets2
      //   0	499	1	paramVarArgs	String[]
      //   7	209	2	localDefaultHttpClient	org.apache.http.impl.client.DefaultHttpClient
      //   65	152	3	localHttpPost	org.apache.http.client.methods.HttpPost
      //   76	37	4	localSharedPreferences	SharedPreferences
      //   92	11	5	arrayOfByte	byte[]
      //   394	3	6	localUnsupportedEncodingException1	UnsupportedEncodingException
      //   122	11	7	str	String
      //   404	3	8	localBadPaddingException	BadPaddingException
      //   469	1	8	localInvalidAlgorithmParameterException	InvalidAlgorithmParameterException
      //   474	1	8	localNoSuchAlgorithmException	NoSuchAlgorithmException
      //   479	1	8	localNoSuchPaddingException	NoSuchPaddingException
      //   484	1	8	localInvalidKeyException	InvalidKeyException
      //   489	1	8	localIllegalBlockSizeException	IllegalBlockSizeException
      //   494	1	8	localUnsupportedEncodingException2	UnsupportedEncodingException
      //   148	56	9	localArrayList	java.util.ArrayList
      //   414	3	12	localUnsupportedEncodingException3	UnsupportedEncodingException
      //   424	3	13	localIOException1	IOException
      //   434	3	14	localIllegalStateException	IllegalStateException
      //   464	1	14	localIOException2	IOException
      //   444	3	15	localIOException3	IOException
      //   454	3	16	localJSONException	JSONException
      // Exception table:
      //   from	to	target	type
      //   94	112	394	java/io/UnsupportedEncodingException
      //   124	140	404	javax/crypto/BadPaddingException
      //   198	211	414	java/io/UnsupportedEncodingException
      //   211	225	424	java/io/IOException
      //   225	249	434	java/lang/IllegalStateException
      //   249	270	444	java/io/IOException
      //   317	376	454	org/json/JSONException
      //   225	249	464	java/io/IOException
      //   124	140	469	java/security/InvalidAlgorithmParameterException
      //   124	140	474	java/security/NoSuchAlgorithmException
      //   124	140	479	javax/crypto/NoSuchPaddingException
      //   124	140	484	java/security/InvalidKeyException
      //   124	140	489	javax/crypto/IllegalBlockSizeException
      //   124	140	494	java/io/UnsupportedEncodingException
    }
    
    public void onPostExecute(String paramString) {}
    
    public void onProgressUpdate(String... paramVarArgs) {}
  }
  
  public class RequestDoTransferTask
    extends AsyncTask<String, String, String>
  {
    public RequestDoTransferTask() {}
    
    public void AsyncHttpTransferPost(String paramString) {}
    
    /* Error */
    protected String doInBackground(String... paramVarArgs)
    {
      // Byte code:
      //   0: new 45	org/apache/http/impl/client/DefaultHttpClient
      //   3: dup
      //   4: invokespecial 46	org/apache/http/impl/client/DefaultHttpClient:<init>	()V
      //   7: astore_2
      //   8: new 48	org/apache/http/client/methods/HttpPost
      //   11: dup
      //   12: new 50	java/lang/StringBuilder
      //   15: dup
      //   16: aload_0
      //   17: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   20: getfield 56	com/android/insecurebankv2/DoTransfer:protocol	Ljava/lang/String;
      //   23: invokestatic 62	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
      //   26: invokespecial 64	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   29: aload_0
      //   30: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   33: getfield 67	com/android/insecurebankv2/DoTransfer:serverip	Ljava/lang/String;
      //   36: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   39: ldc 73
      //   41: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   44: aload_0
      //   45: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   48: getfield 76	com/android/insecurebankv2/DoTransfer:serverport	Ljava/lang/String;
      //   51: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   54: ldc 78
      //   56: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   59: invokevirtual 82	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   62: invokespecial 83	org/apache/http/client/methods/HttpPost:<init>	(Ljava/lang/String;)V
      //   65: astore_3
      //   66: aload_0
      //   67: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   70: ldc 85
      //   72: iconst_0
      //   73: invokevirtual 89	com/android/insecurebankv2/DoTransfer:getSharedPreferences	(Ljava/lang/String;I)Landroid/content/SharedPreferences;
      //   76: astore 4
      //   78: aload 4
      //   80: ldc 91
      //   82: aconst_null
      //   83: invokeinterface 97 3 0
      //   88: iconst_0
      //   89: invokestatic 103	android/util/Base64:decode	(Ljava/lang/String;I)[B
      //   92: astore 5
      //   94: aload_0
      //   95: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   98: new 58	java/lang/String
      //   101: dup
      //   102: aload 5
      //   104: ldc 105
      //   106: invokespecial 108	java/lang/String:<init>	([BLjava/lang/String;)V
      //   109: putfield 111	com/android/insecurebankv2/DoTransfer:usernameBase64ByteString	Ljava/lang/String;
      //   112: aload 4
      //   114: ldc 113
      //   116: aconst_null
      //   117: invokeinterface 97 3 0
      //   122: astore 7
      //   124: aload_0
      //   125: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   128: aload_0
      //   129: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   132: aload 7
      //   134: invokestatic 117	com/android/insecurebankv2/DoTransfer:access$0	(Lcom/android/insecurebankv2/DoTransfer;Ljava/lang/String;)Ljava/lang/String;
      //   137: putfield 120	com/android/insecurebankv2/DoTransfer:passNormalized	Ljava/lang/String;
      //   140: new 122	java/util/ArrayList
      //   143: dup
      //   144: iconst_5
      //   145: invokespecial 125	java/util/ArrayList:<init>	(I)V
      //   148: astore 9
      //   150: aload 9
      //   152: new 127	org/apache/http/message/BasicNameValuePair
      //   155: dup
      //   156: ldc -127
      //   158: aload_0
      //   159: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   162: getfield 111	com/android/insecurebankv2/DoTransfer:usernameBase64ByteString	Ljava/lang/String;
      //   165: invokespecial 132	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
      //   168: invokeinterface 138 2 0
      //   173: pop
      //   174: aload 9
      //   176: new 127	org/apache/http/message/BasicNameValuePair
      //   179: dup
      //   180: ldc -116
      //   182: aload_0
      //   183: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   186: getfield 120	com/android/insecurebankv2/DoTransfer:passNormalized	Ljava/lang/String;
      //   189: invokespecial 132	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
      //   192: invokeinterface 138 2 0
      //   197: pop
      //   198: aload_0
      //   199: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   202: aload_0
      //   203: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   206: ldc -115
      //   208: invokevirtual 145	com/android/insecurebankv2/DoTransfer:findViewById	(I)Landroid/view/View;
      //   211: checkcast 147	android/widget/EditText
      //   214: putfield 151	com/android/insecurebankv2/DoTransfer:from	Landroid/widget/EditText;
      //   217: aload_0
      //   218: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   221: aload_0
      //   222: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   225: ldc -104
      //   227: invokevirtual 145	com/android/insecurebankv2/DoTransfer:findViewById	(I)Landroid/view/View;
      //   230: checkcast 147	android/widget/EditText
      //   233: putfield 155	com/android/insecurebankv2/DoTransfer:to	Landroid/widget/EditText;
      //   236: aload_0
      //   237: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   240: aload_0
      //   241: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   244: ldc -100
      //   246: invokevirtual 145	com/android/insecurebankv2/DoTransfer:findViewById	(I)Landroid/view/View;
      //   249: checkcast 147	android/widget/EditText
      //   252: putfield 159	com/android/insecurebankv2/DoTransfer:amount	Landroid/widget/EditText;
      //   255: aload 9
      //   257: new 127	org/apache/http/message/BasicNameValuePair
      //   260: dup
      //   261: ldc -95
      //   263: aload_0
      //   264: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   267: getfield 151	com/android/insecurebankv2/DoTransfer:from	Landroid/widget/EditText;
      //   270: invokevirtual 165	android/widget/EditText:getText	()Landroid/text/Editable;
      //   273: invokeinterface 168 1 0
      //   278: invokespecial 132	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
      //   281: invokeinterface 138 2 0
      //   286: pop
      //   287: aload 9
      //   289: new 127	org/apache/http/message/BasicNameValuePair
      //   292: dup
      //   293: ldc -86
      //   295: aload_0
      //   296: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   299: getfield 155	com/android/insecurebankv2/DoTransfer:to	Landroid/widget/EditText;
      //   302: invokevirtual 165	android/widget/EditText:getText	()Landroid/text/Editable;
      //   305: invokeinterface 168 1 0
      //   310: invokespecial 132	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
      //   313: invokeinterface 138 2 0
      //   318: pop
      //   319: aload 9
      //   321: new 127	org/apache/http/message/BasicNameValuePair
      //   324: dup
      //   325: ldc -85
      //   327: aload_0
      //   328: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   331: getfield 159	com/android/insecurebankv2/DoTransfer:amount	Landroid/widget/EditText;
      //   334: invokevirtual 165	android/widget/EditText:getText	()Landroid/text/Editable;
      //   337: invokeinterface 168 1 0
      //   342: invokespecial 132	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
      //   345: invokeinterface 138 2 0
      //   350: pop
      //   351: aload_3
      //   352: new 173	org/apache/http/client/entity/UrlEncodedFormEntity
      //   355: dup
      //   356: aload 9
      //   358: invokespecial 176	org/apache/http/client/entity/UrlEncodedFormEntity:<init>	(Ljava/util/List;)V
      //   361: invokevirtual 180	org/apache/http/client/methods/HttpPost:setEntity	(Lorg/apache/http/HttpEntity;)V
      //   364: aload_0
      //   365: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   368: aload_2
      //   369: aload_3
      //   370: invokeinterface 186 2 0
      //   375: putfield 190	com/android/insecurebankv2/DoTransfer:responseBody	Lorg/apache/http/HttpResponse;
      //   378: aload_0
      //   379: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   382: aload_0
      //   383: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   386: getfield 190	com/android/insecurebankv2/DoTransfer:responseBody	Lorg/apache/http/HttpResponse;
      //   389: invokeinterface 196 1 0
      //   394: invokeinterface 202 1 0
      //   399: putfield 206	com/android/insecurebankv2/DoTransfer:in	Ljava/io/InputStream;
      //   402: aload_0
      //   403: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   406: aload_0
      //   407: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   410: aload_0
      //   411: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   414: getfield 206	com/android/insecurebankv2/DoTransfer:in	Ljava/io/InputStream;
      //   417: invokevirtual 210	com/android/insecurebankv2/DoTransfer:convertStreamToString	(Ljava/io/InputStream;)Ljava/lang/String;
      //   420: putfield 213	com/android/insecurebankv2/DoTransfer:result	Ljava/lang/String;
      //   423: aload_0
      //   424: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   427: aload_0
      //   428: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   431: getfield 213	com/android/insecurebankv2/DoTransfer:result	Ljava/lang/String;
      //   434: ldc -41
      //   436: ldc -39
      //   438: invokevirtual 221	java/lang/String:replace	(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
      //   441: putfield 213	com/android/insecurebankv2/DoTransfer:result	Ljava/lang/String;
      //   444: aload_0
      //   445: getfield 11	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask:this$0	Lcom/android/insecurebankv2/DoTransfer;
      //   448: new 223	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask$1
      //   451: dup
      //   452: aload_0
      //   453: invokespecial 226	com/android/insecurebankv2/DoTransfer$RequestDoTransferTask$1:<init>	(Lcom/android/insecurebankv2/DoTransfer$RequestDoTransferTask;)V
      //   456: invokevirtual 230	com/android/insecurebankv2/DoTransfer:runOnUiThread	(Ljava/lang/Runnable;)V
      //   459: ldc -24
      //   461: areturn
      //   462: astore 6
      //   464: aload 6
      //   466: invokevirtual 235	java/io/UnsupportedEncodingException:printStackTrace	()V
      //   469: goto -357 -> 112
      //   472: astore 8
      //   474: aload 8
      //   476: invokevirtual 238	java/lang/Exception:printStackTrace	()V
      //   479: goto -339 -> 140
      //   482: astore 15
      //   484: aload 15
      //   486: invokevirtual 235	java/io/UnsupportedEncodingException:printStackTrace	()V
      //   489: goto -125 -> 364
      //   492: astore 16
      //   494: aload 16
      //   496: invokevirtual 239	java/io/IOException:printStackTrace	()V
      //   499: goto -121 -> 378
      //   502: astore 17
      //   504: aload 17
      //   506: invokevirtual 238	java/lang/Exception:printStackTrace	()V
      //   509: goto -107 -> 402
      //   512: astore 18
      //   514: aload 18
      //   516: invokevirtual 239	java/io/IOException:printStackTrace	()V
      //   519: goto -96 -> 423
      //   522: astore 17
      //   524: goto -20 -> 504
      //   527: astore 8
      //   529: goto -55 -> 474
      //   532: astore 8
      //   534: goto -60 -> 474
      //   537: astore 8
      //   539: goto -65 -> 474
      //   542: astore 8
      //   544: goto -70 -> 474
      //   547: astore 8
      //   549: goto -75 -> 474
      //   552: astore 8
      //   554: goto -80 -> 474
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	557	0	this	RequestDoTransferTask
      //   0	557	1	paramVarArgs	String[]
      //   7	362	2	localDefaultHttpClient	org.apache.http.impl.client.DefaultHttpClient
      //   65	305	3	localHttpPost	org.apache.http.client.methods.HttpPost
      //   76	37	4	localSharedPreferences	SharedPreferences
      //   92	11	5	arrayOfByte	byte[]
      //   462	3	6	localUnsupportedEncodingException1	UnsupportedEncodingException
      //   122	11	7	str	String
      //   472	3	8	localBadPaddingException	BadPaddingException
      //   527	1	8	localInvalidAlgorithmParameterException	InvalidAlgorithmParameterException
      //   532	1	8	localNoSuchAlgorithmException	NoSuchAlgorithmException
      //   537	1	8	localNoSuchPaddingException	NoSuchPaddingException
      //   542	1	8	localInvalidKeyException	InvalidKeyException
      //   547	1	8	localIllegalBlockSizeException	IllegalBlockSizeException
      //   552	1	8	localUnsupportedEncodingException2	UnsupportedEncodingException
      //   148	209	9	localArrayList	java.util.ArrayList
      //   482	3	15	localUnsupportedEncodingException3	UnsupportedEncodingException
      //   492	3	16	localIOException1	IOException
      //   502	3	17	localIllegalStateException	IllegalStateException
      //   522	1	17	localIOException2	IOException
      //   512	3	18	localIOException3	IOException
      // Exception table:
      //   from	to	target	type
      //   94	112	462	java/io/UnsupportedEncodingException
      //   124	140	472	javax/crypto/BadPaddingException
      //   351	364	482	java/io/UnsupportedEncodingException
      //   364	378	492	java/io/IOException
      //   378	402	502	java/lang/IllegalStateException
      //   402	423	512	java/io/IOException
      //   378	402	522	java/io/IOException
      //   124	140	527	java/security/InvalidAlgorithmParameterException
      //   124	140	532	java/security/NoSuchAlgorithmException
      //   124	140	537	javax/crypto/NoSuchPaddingException
      //   124	140	542	java/security/InvalidKeyException
      //   124	140	547	javax/crypto/IllegalBlockSizeException
      //   124	140	552	java/io/UnsupportedEncodingException
    }
    
    protected void onPostExecute(String paramString) {}
    
    protected void onProgressUpdate(String... paramVarArgs) {}
  }
}
