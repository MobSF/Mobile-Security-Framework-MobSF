package com.android.insecurebankv2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;

public class MyBroadCastReceiver
  extends BroadcastReceiver
{
  public MyBroadCastReceiver() {}
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str1 = paramIntent.getStringExtra("phonenumber");
    if (str1 != null) {}
    try
    {
      String str2 = str1.toString();
      SmsManager.getDefault().sendTextMessage(str2, null, "Transaction Successful", null, null);
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}
