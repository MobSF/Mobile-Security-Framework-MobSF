package com.android.insecurebankv2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class PostLogin
  extends Activity
{
  Button changepasswd_button;
  Button statement_button;
  Button transfer_button;
  String uname;
  
  public PostLogin() {}
  
  public void callPreferences()
  {
    startActivity(new Intent(this, FilePrefActivity.class));
  }
  
  protected void changePasswd()
  {
    Intent localIntent = new Intent(getApplicationContext(), ChangePassword.class);
    localIntent.putExtra("uname", uname);
    startActivity(localIntent);
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903069);
    uname = getIntent().getStringExtra("uname");
    transfer_button = ((Button)findViewById(2131034196));
    transfer_button.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent(getApplicationContext(), DoTransfer.class);
        startActivity(localIntent);
      }
    });
    statement_button = ((Button)findViewById(2131034197));
    statement_button.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        viewStatment();
      }
    });
    changepasswd_button = ((Button)findViewById(2131034198));
    changepasswd_button.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        changePasswd();
      }
    });
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131492866, paramMenu);
    return true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    int i = paramMenuItem.getItemId();
    if (i == 2131034200)
    {
      callPreferences();
      return true;
    }
    if (i == 2131034201)
    {
      Intent localIntent = new Intent(getBaseContext(), LoginActivity.class);
      localIntent.addFlags(67108864);
      startActivity(localIntent);
      return true;
    }
    return super.onOptionsItemSelected(paramMenuItem);
  }
  
  protected void viewStatment()
  {
    Intent localIntent = new Intent(getApplicationContext(), ViewStatement.class);
    localIntent.putExtra("uname", uname);
    startActivity(localIntent);
  }
}
