package com.android.insecurebankv2;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.CheckBox;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DoLogin
  extends Activity
{
  public static final String MYPREFS = "mySharedPreferences";
  static JSONObject jObj = null;
  String base64Text;
  JSONArray contacts = null;
  StringBuilder contents = new StringBuilder();
  String login_response_message;
  String login_response_user;
  String password;
  String protocol = "http://";
  BufferedReader reader;
  CheckBox remember;
  String rememberme_password;
  String rememberme_username;
  String responseString = null;
  String result;
  String serverip = "";
  String serverport = "";
  String superSecurePassword;
  String superSecureUsername;
  String username;
  
  public DoLogin() {}
  
  public void callPreferences()
  {
    startActivity(new Intent(this, FilePrefActivity.class));
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903065);
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
    serverip = localSharedPreferences.getString("serverip", null);
    serverport = localSharedPreferences.getString("serverport", null);
    Intent localIntent = getIntent();
    username = localIntent.getStringExtra("passed_username");
    password = localIntent.getStringExtra("passed_password");
    new RequestTask().execute(new String[] { "username" });
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131492866, paramMenu);
    return true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    int i = paramMenuItem.getItemId();
    if (i == 2131034200)
    {
      callPreferences();
      return true;
    }
    if (i == 2131034201)
    {
      Intent localIntent = new Intent(getBaseContext(), LoginActivity.class);
      localIntent.addFlags(67108864);
      startActivity(localIntent);
      return true;
    }
    return super.onOptionsItemSelected(paramMenuItem);
  }
  
  class RequestTask
    extends AsyncTask<String, String, String>
  {
    RequestTask() {}
    
    private String convertStreamToString(InputStream paramInputStream)
      throws IOException
    {
      try
      {
        reader = new BufferedReader(new InputStreamReader(paramInputStream, "UTF-8"));
        localStringBuilder = new StringBuilder();
        str = reader.readLine();
        if (str == null)
        {
          paramInputStream.close();
          return localStringBuilder.toString();
        }
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        for (;;)
        {
          StringBuilder localStringBuilder;
          String str;
          localUnsupportedEncodingException.printStackTrace();
          continue;
          localStringBuilder.append(str + "\n");
        }
      }
    }
    
    private void saveCreds(String paramString1, String paramString2)
      throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException
    {
      SharedPreferences.Editor localEditor = getSharedPreferences("mySharedPreferences", 0).edit();
      rememberme_username = paramString1;
      rememberme_password = paramString2;
      String str = new String(Base64.encodeToString(rememberme_username.getBytes(), 4));
      CryptoClass localCryptoClass = new CryptoClass();
      superSecurePassword = localCryptoClass.aesEncryptedString(rememberme_password);
      localEditor.putString("EncryptedUsername", str);
      localEditor.putString("superSecurePassword", superSecurePassword);
      localEditor.commit();
    }
    
    private void trackUserLogins()
    {
      runOnUiThread(new Runnable()
      {
        public void run()
        {
          ContentValues localContentValues = new ContentValues();
          localContentValues.put("name", username);
          getContentResolver().insert(TrackUserContentProvider.CONTENT_URI, localContentValues);
        }
      });
    }
    
    protected String doInBackground(String... paramVarArgs)
    {
      try
      {
        postData(paramVarArgs[0]);
        return null;
      }
      catch (BadPaddingException localBadPaddingException)
      {
        for (;;)
        {
          localBadPaddingException.printStackTrace();
        }
      }
      catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
      {
        for (;;) {}
      }
      catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
      {
        for (;;) {}
      }
      catch (JSONException localJSONException)
      {
        for (;;) {}
      }
      catch (NoSuchPaddingException localNoSuchPaddingException)
      {
        for (;;) {}
      }
      catch (IOException localIOException)
      {
        for (;;) {}
      }
      catch (InvalidKeyException localInvalidKeyException)
      {
        for (;;) {}
      }
      catch (IllegalBlockSizeException localIllegalBlockSizeException)
      {
        for (;;) {}
      }
    }
    
    protected void onPostExecute(Double paramDouble) {}
    
    protected void onProgressUpdate(Integer... paramVarArgs) {}
    
    public void postData(String paramString)
      throws ClientProtocolException, IOException, JSONException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException
    {
      DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient();
      HttpPost localHttpPost1 = new HttpPost(protocol + serverip + ":" + serverport + "/login");
      HttpPost localHttpPost2 = new HttpPost(protocol + serverip + ":" + serverport + "/devlogin");
      ArrayList localArrayList = new ArrayList(2);
      localArrayList.add(new BasicNameValuePair("username", username));
      localArrayList.add(new BasicNameValuePair("password", password));
      if (username.equals("devadmin")) {
        localHttpPost2.setEntity(new UrlEncodedFormEntity(localArrayList));
      }
      for (HttpResponse localHttpResponse = localDefaultHttpClient.execute(localHttpPost2);; localHttpResponse = localDefaultHttpClient.execute(localHttpPost1))
      {
        InputStream localInputStream = localHttpResponse.getEntity().getContent();
        result = convertStreamToString(localInputStream);
        result = result.replace("\n", "");
        if (result != null)
        {
          if (result.indexOf("Correct Credentials") == -1) {
            break;
          }
          Log.d("Successful Login:", ", account=" + username + ":" + password);
          saveCreds(username, password);
          trackUserLogins();
          Intent localIntent2 = new Intent(getApplicationContext(), PostLogin.class);
          localIntent2.putExtra("uname", username);
          startActivity(localIntent2);
        }
        return;
        localHttpPost1.setEntity(new UrlEncodedFormEntity(localArrayList));
      }
      Intent localIntent1 = new Intent(getApplicationContext(), WrongLogin.class);
      startActivity(localIntent1);
    }
  }
}
