package com.android.insecurebankv2;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class LoginActivity
  extends Activity
{
  public static final String MYPREFS = "mySharedPreferences";
  EditText Password_Text;
  EditText Username_Text;
  Button fillData_button;
  Button login_buttons;
  String password_text;
  String usernameBase64ByteString;
  String username_text;
  
  public LoginActivity() {}
  
  public void callPreferences()
  {
    startActivity(new Intent(this, FilePrefActivity.class));
  }
  
  protected void fillData()
    throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException
  {
    SharedPreferences localSharedPreferences = getSharedPreferences("mySharedPreferences", 0);
    byte[] arrayOfByte = Base64.decode(localSharedPreferences.getString("EncryptedUsername", null), 0);
    try
    {
      usernameBase64ByteString = new String(arrayOfByte, "UTF-8");
      String str1 = localSharedPreferences.getString("superSecurePassword", null);
      Username_Text = ((EditText)findViewById(2131034194));
      Password_Text = ((EditText)findViewById(2131034192));
      Username_Text.setText(usernameBase64ByteString);
      String str2 = new CryptoClass().aesDeccryptedString(str1);
      Password_Text.setText(str2);
      return;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      for (;;)
      {
        localUnsupportedEncodingException.printStackTrace();
      }
    }
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903068);
    if (getResources().getString(2131361824).equals("no")) {
      findViewById(2131034181).setVisibility(8);
    }
    login_buttons = ((Button)findViewById(2131034191));
    login_buttons.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        performlogin();
      }
    });
    fillData_button = ((Button)findViewById(2131034193));
    fillData_button.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        try
        {
          fillData();
          return;
        }
        catch (BadPaddingException localBadPaddingException)
        {
          localBadPaddingException.printStackTrace();
          return;
        }
        catch (InvalidAlgorithmParameterException localInvalidAlgorithmParameterException)
        {
          for (;;) {}
        }
        catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
        {
          for (;;) {}
        }
        catch (NoSuchPaddingException localNoSuchPaddingException)
        {
          for (;;) {}
        }
        catch (InvalidKeyException localInvalidKeyException)
        {
          for (;;) {}
        }
        catch (IllegalBlockSizeException localIllegalBlockSizeException)
        {
          for (;;) {}
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException)
        {
          for (;;) {}
        }
      }
    });
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131492866, paramMenu);
    return true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    int i = paramMenuItem.getItemId();
    if (i == 2131034200)
    {
      callPreferences();
      return true;
    }
    if (i == 2131034201)
    {
      Intent localIntent = new Intent(getBaseContext(), LoginActivity.class);
      localIntent.addFlags(67108864);
      startActivity(localIntent);
      return true;
    }
    return super.onOptionsItemSelected(paramMenuItem);
  }
  
  protected void performlogin()
  {
    Username_Text = ((EditText)findViewById(2131034194));
    Password_Text = ((EditText)findViewById(2131034192));
    Intent localIntent = new Intent(this, DoLogin.class);
    localIntent.putExtra("passed_username", Username_Text.getText().toString());
    localIntent.putExtra("passed_password", Password_Text.getText().toString());
    startActivity(localIntent);
  }
}
