package android.support.v7.app;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.annotation.NonNull;
import android.support.v4.app.NavUtils;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewConfigurationCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v7.appcompat.R.attr;
import android.support.v7.appcompat.R.color;
import android.support.v7.appcompat.R.id;
import android.support.v7.appcompat.R.layout;
import android.support.v7.appcompat.R.style;
import android.support.v7.appcompat.R.styleable;
import android.support.v7.internal.app.ToolbarActionBar;
import android.support.v7.internal.app.WindowCallback;
import android.support.v7.internal.app.WindowDecorActionBar;
import android.support.v7.internal.view.StandaloneActionMode;
import android.support.v7.internal.view.menu.ListMenuPresenter;
import android.support.v7.internal.view.menu.MenuBuilder;
import android.support.v7.internal.view.menu.MenuBuilder.Callback;
import android.support.v7.internal.view.menu.MenuPresenter.Callback;
import android.support.v7.internal.view.menu.MenuView;
import android.support.v7.internal.widget.ActionBarContextView;
import android.support.v7.internal.widget.DecorContentParent;
import android.support.v7.internal.widget.FitWindowsViewGroup;
import android.support.v7.internal.widget.FitWindowsViewGroup.OnFitSystemWindowsListener;
import android.support.v7.internal.widget.TintCheckBox;
import android.support.v7.internal.widget.TintCheckedTextView;
import android.support.v7.internal.widget.TintEditText;
import android.support.v7.internal.widget.TintRadioButton;
import android.support.v7.internal.widget.TintSpinner;
import android.support.v7.internal.widget.ViewStubCompat;
import android.support.v7.internal.widget.ViewUtils;
import android.support.v7.view.ActionMode;
import android.support.v7.view.ActionMode.Callback;
import android.support.v7.widget.Toolbar;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.PopupWindow;

class ActionBarActivityDelegateBase
  extends ActionBarActivityDelegate
  implements MenuBuilder.Callback
{
  private static final String TAG = "ActionBarActivityDelegateBase";
  private ActionMenuPresenterCallback mActionMenuPresenterCallback;
  ActionMode mActionMode;
  PopupWindow mActionModePopup;
  ActionBarContextView mActionModeView;
  private boolean mClosingActionMenu;
  private DecorContentParent mDecorContentParent;
  private boolean mEnableDefaultActionBarUp;
  private boolean mFeatureIndeterminateProgress;
  private boolean mFeatureProgress;
  private int mInvalidatePanelMenuFeatures;
  private boolean mInvalidatePanelMenuPosted;
  private final Runnable mInvalidatePanelMenuRunnable = new Runnable()
  {
    public void run()
    {
      if ((0x1 & mInvalidatePanelMenuFeatures) != 0) {
        ActionBarActivityDelegateBase.this.doInvalidatePanelMenu(0);
      }
      if ((0x100 & mInvalidatePanelMenuFeatures) != 0) {
        ActionBarActivityDelegateBase.this.doInvalidatePanelMenu(8);
      }
      ActionBarActivityDelegateBase.access$202(ActionBarActivityDelegateBase.this, false);
      ActionBarActivityDelegateBase.access$002(ActionBarActivityDelegateBase.this, 0);
    }
  };
  private PanelMenuPresenterCallback mPanelMenuPresenterCallback;
  private PanelFeatureState[] mPanels;
  private PanelFeatureState mPreparedPanel;
  Runnable mShowActionModePopup;
  private View mStatusGuard;
  private ViewGroup mSubDecor;
  private boolean mSubDecorInstalled;
  private Rect mTempRect1;
  private Rect mTempRect2;
  private CharSequence mTitleToSet;
  private ListMenuPresenter mToolbarListMenuPresenter;
  private ViewGroup mWindowDecor;
  
  ActionBarActivityDelegateBase(ActionBarActivity paramActionBarActivity)
  {
    super(paramActionBarActivity);
  }
  
  private void applyFixedSizeWindow()
  {
    TypedArray localTypedArray = mActivity.obtainStyledAttributes(R.styleable.Theme);
    boolean bool1 = localTypedArray.hasValue(R.styleable.Theme_windowFixedWidthMajor);
    TypedValue localTypedValue1 = null;
    if (bool1)
    {
      localTypedValue1 = null;
      if (0 == 0) {
        localTypedValue1 = new TypedValue();
      }
      localTypedArray.getValue(R.styleable.Theme_windowFixedWidthMajor, localTypedValue1);
    }
    boolean bool2 = localTypedArray.hasValue(R.styleable.Theme_windowFixedWidthMinor);
    TypedValue localTypedValue2 = null;
    if (bool2)
    {
      localTypedValue2 = null;
      if (0 == 0) {
        localTypedValue2 = new TypedValue();
      }
      localTypedArray.getValue(R.styleable.Theme_windowFixedWidthMinor, localTypedValue2);
    }
    boolean bool3 = localTypedArray.hasValue(R.styleable.Theme_windowFixedHeightMajor);
    TypedValue localTypedValue3 = null;
    if (bool3)
    {
      localTypedValue3 = null;
      if (0 == 0) {
        localTypedValue3 = new TypedValue();
      }
      localTypedArray.getValue(R.styleable.Theme_windowFixedHeightMajor, localTypedValue3);
    }
    boolean bool4 = localTypedArray.hasValue(R.styleable.Theme_windowFixedHeightMinor);
    TypedValue localTypedValue4 = null;
    if (bool4)
    {
      localTypedValue4 = null;
      if (0 == 0) {
        localTypedValue4 = new TypedValue();
      }
      localTypedArray.getValue(R.styleable.Theme_windowFixedHeightMinor, localTypedValue4);
    }
    DisplayMetrics localDisplayMetrics = mActivity.getResources().getDisplayMetrics();
    int i;
    int j;
    int k;
    TypedValue localTypedValue5;
    label220:
    label252:
    TypedValue localTypedValue6;
    if (widthPixels < heightPixels)
    {
      i = 1;
      j = -1;
      k = -1;
      if (i == 0) {
        break label330;
      }
      localTypedValue5 = localTypedValue2;
      if ((localTypedValue5 != null) && (type != 0))
      {
        if (type != 5) {
          break label336;
        }
        j = (int)localTypedValue5.getDimension(localDisplayMetrics);
      }
      if (i == 0) {
        break label369;
      }
      localTypedValue6 = localTypedValue3;
      label261:
      if ((localTypedValue6 != null) && (type != 0))
      {
        if (type != 5) {
          break label376;
        }
        k = (int)localTypedValue6.getDimension(localDisplayMetrics);
      }
    }
    for (;;)
    {
      if ((j != -1) || (k != -1)) {
        mActivity.getWindow().setLayout(j, k);
      }
      localTypedArray.recycle();
      return;
      i = 0;
      break;
      label330:
      localTypedValue5 = localTypedValue1;
      break label220;
      label336:
      if (type != 6) {
        break label252;
      }
      j = (int)localTypedValue5.getFraction(widthPixels, widthPixels);
      break label252;
      label369:
      localTypedValue6 = localTypedValue4;
      break label261;
      label376:
      if (type == 6) {
        k = (int)localTypedValue6.getFraction(heightPixels, heightPixels);
      }
    }
  }
  
  private void callOnPanelClosed(int paramInt, PanelFeatureState paramPanelFeatureState, Menu paramMenu)
  {
    if (paramMenu == null)
    {
      if ((paramPanelFeatureState == null) && (paramInt >= 0) && (paramInt < mPanels.length)) {
        paramPanelFeatureState = mPanels[paramInt];
      }
      if (paramPanelFeatureState != null) {
        paramMenu = menu;
      }
    }
    if ((paramPanelFeatureState != null) && (!isOpen)) {
      return;
    }
    getWindowCallback().onPanelClosed(paramInt, paramMenu);
  }
  
  private void checkCloseActionMenu(MenuBuilder paramMenuBuilder)
  {
    if (mClosingActionMenu) {
      return;
    }
    mClosingActionMenu = true;
    mDecorContentParent.dismissPopups();
    WindowCallback localWindowCallback = getWindowCallback();
    if ((localWindowCallback != null) && (!isDestroyed())) {
      localWindowCallback.onPanelClosed(8, paramMenuBuilder);
    }
    mClosingActionMenu = false;
  }
  
  private void closePanel(PanelFeatureState paramPanelFeatureState, boolean paramBoolean)
  {
    if ((paramBoolean) && (featureId == 0) && (mDecorContentParent != null) && (mDecorContentParent.isOverflowMenuShowing())) {
      checkCloseActionMenu(menu);
    }
    do
    {
      return;
      if ((isOpen) && (paramBoolean)) {
        callOnPanelClosed(featureId, paramPanelFeatureState, null);
      }
      isPrepared = false;
      isHandled = false;
      isOpen = false;
      shownPanelView = null;
      refreshDecorView = true;
    } while (mPreparedPanel != paramPanelFeatureState);
    mPreparedPanel = null;
  }
  
  private void doInvalidatePanelMenu(int paramInt)
  {
    PanelFeatureState localPanelFeatureState1 = getPanelState(paramInt, true);
    if (menu != null)
    {
      Bundle localBundle = new Bundle();
      menu.saveActionViewStates(localBundle);
      if (localBundle.size() > 0) {
        frozenActionViewState = localBundle;
      }
      menu.stopDispatchingItemsChanged();
      menu.clear();
    }
    refreshMenuContent = true;
    refreshDecorView = true;
    if (((paramInt == 8) || (paramInt == 0)) && (mDecorContentParent != null))
    {
      PanelFeatureState localPanelFeatureState2 = getPanelState(0, false);
      if (localPanelFeatureState2 != null)
      {
        isPrepared = false;
        preparePanel(localPanelFeatureState2, null);
      }
    }
  }
  
  private void ensureToolbarListMenuPresenter()
  {
    TypedValue localTypedValue;
    ActionBarActivity localActionBarActivity;
    if (mToolbarListMenuPresenter == null)
    {
      localTypedValue = new TypedValue();
      mActivity.getTheme().resolveAttribute(R.attr.panelMenuListTheme, localTypedValue, true);
      localActionBarActivity = mActivity;
      if (resourceId == 0) {
        break label74;
      }
    }
    label74:
    for (int i = resourceId;; i = R.style.Theme_AppCompat_CompactMenu)
    {
      mToolbarListMenuPresenter = new ListMenuPresenter(new ContextThemeWrapper(localActionBarActivity, i), R.layout.abc_list_menu_item_layout);
      return;
    }
  }
  
  private PanelFeatureState findMenuPanel(Menu paramMenu)
  {
    PanelFeatureState[] arrayOfPanelFeatureState = mPanels;
    int i;
    if (arrayOfPanelFeatureState != null) {
      i = arrayOfPanelFeatureState.length;
    }
    for (int j = 0;; j++)
    {
      if (j >= i) {
        break label55;
      }
      PanelFeatureState localPanelFeatureState = arrayOfPanelFeatureState[j];
      if ((localPanelFeatureState != null) && (menu == paramMenu))
      {
        return localPanelFeatureState;
        i = 0;
        break;
      }
    }
    label55:
    return null;
  }
  
  private PanelFeatureState getPanelState(int paramInt, boolean paramBoolean)
  {
    Object localObject = mPanels;
    if ((localObject == null) || (localObject.length <= paramInt))
    {
      PanelFeatureState[] arrayOfPanelFeatureState = new PanelFeatureState[paramInt + 1];
      if (localObject != null) {
        System.arraycopy(localObject, 0, arrayOfPanelFeatureState, 0, localObject.length);
      }
      localObject = arrayOfPanelFeatureState;
      mPanels = arrayOfPanelFeatureState;
    }
    PanelFeatureState localPanelFeatureState = localObject[paramInt];
    if (localPanelFeatureState == null)
    {
      localPanelFeatureState = new PanelFeatureState(paramInt);
      localObject[paramInt] = localPanelFeatureState;
    }
    return localPanelFeatureState;
  }
  
  private boolean initializePanelContent(PanelFeatureState paramPanelFeatureState)
  {
    if (menu == null) {}
    do
    {
      return false;
      if (mPanelMenuPresenterCallback == null) {
        mPanelMenuPresenterCallback = new PanelMenuPresenterCallback(null);
      }
      shownPanelView = ((View)paramPanelFeatureState.getListMenuView(mPanelMenuPresenterCallback));
    } while (shownPanelView == null);
    return true;
  }
  
  private void initializePanelDecor(PanelFeatureState paramPanelFeatureState)
  {
    decorView = mWindowDecor;
    paramPanelFeatureState.setStyle(getActionBarThemedContext());
  }
  
  private boolean initializePanelMenu(PanelFeatureState paramPanelFeatureState)
  {
    Object localObject = mActivity;
    TypedValue localTypedValue;
    Resources.Theme localTheme1;
    Resources.Theme localTheme2;
    if (((featureId == 0) || (featureId == 8)) && (mDecorContentParent != null))
    {
      localTypedValue = new TypedValue();
      localTheme1 = ((Context)localObject).getTheme();
      localTheme1.resolveAttribute(R.attr.actionBarTheme, localTypedValue, true);
      if (resourceId == 0) {
        break label188;
      }
      localTheme2 = ((Context)localObject).getResources().newTheme();
      localTheme2.setTo(localTheme1);
      localTheme2.applyStyle(resourceId, true);
      localTheme2.resolveAttribute(R.attr.actionBarWidgetTheme, localTypedValue, true);
    }
    for (;;)
    {
      if (resourceId != 0)
      {
        if (localTheme2 == null)
        {
          localTheme2 = ((Context)localObject).getResources().newTheme();
          localTheme2.setTo(localTheme1);
        }
        localTheme2.applyStyle(resourceId, true);
      }
      if (localTheme2 != null)
      {
        ContextThemeWrapper localContextThemeWrapper = new ContextThemeWrapper((Context)localObject, 0);
        localContextThemeWrapper.getTheme().setTo(localTheme2);
        localObject = localContextThemeWrapper;
      }
      MenuBuilder localMenuBuilder = new MenuBuilder((Context)localObject);
      localMenuBuilder.setCallback(this);
      paramPanelFeatureState.setMenu(localMenuBuilder);
      return true;
      label188:
      localTheme1.resolveAttribute(R.attr.actionBarWidgetTheme, localTypedValue, true);
      localTheme2 = null;
    }
  }
  
  private void invalidatePanelMenu(int paramInt)
  {
    mInvalidatePanelMenuFeatures |= 1 << paramInt;
    if ((!mInvalidatePanelMenuPosted) && (mWindowDecor != null))
    {
      ViewCompat.postOnAnimation(mWindowDecor, mInvalidatePanelMenuRunnable);
      mInvalidatePanelMenuPosted = true;
    }
  }
  
  private void openPanel(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 0) && (mDecorContentParent != null) && (mDecorContentParent.canShowOverflowMenu()) && (!ViewConfigurationCompat.hasPermanentMenuKey(ViewConfiguration.get(mActivity))))
    {
      mDecorContentParent.showOverflowMenu();
      return;
    }
    openPanel(getPanelState(paramInt, true), paramKeyEvent);
  }
  
  private void openPanel(PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent)
  {
    if ((isOpen) || (isDestroyed())) {}
    label108:
    label114:
    label118:
    label120:
    do
    {
      do
      {
        for (;;)
        {
          return;
          int i;
          if (featureId == 0)
          {
            ActionBarActivity localActionBarActivity = mActivity;
            if ((0xF & getResourcesgetConfigurationscreenLayout) != 4) {
              break label108;
            }
            i = 1;
            if (getApplicationInfotargetSdkVersion < 11) {
              break label114;
            }
          }
          for (int j = 1;; j = 0)
          {
            if ((i != 0) && (j != 0)) {
              break label118;
            }
            WindowCallback localWindowCallback = getWindowCallback();
            if ((localWindowCallback == null) || (localWindowCallback.onMenuOpened(featureId, menu))) {
              break label120;
            }
            closePanel(paramPanelFeatureState, true);
            return;
            i = 0;
            break;
          }
        }
      } while (!preparePanel(paramPanelFeatureState, paramKeyEvent));
      if ((decorView == null) || (refreshDecorView)) {
        initializePanelDecor(paramPanelFeatureState);
      }
    } while ((!initializePanelContent(paramPanelFeatureState)) || (!paramPanelFeatureState.hasPanelItems()));
    isHandled = false;
    isOpen = true;
  }
  
  private boolean preparePanel(PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent)
  {
    if (isDestroyed()) {
      return false;
    }
    if (isPrepared) {
      return true;
    }
    if ((mPreparedPanel != null) && (mPreparedPanel != paramPanelFeatureState)) {
      closePanel(mPreparedPanel, false);
    }
    if ((featureId == 0) || (featureId == 8)) {}
    for (int i = 1;; i = 0)
    {
      if ((i != 0) && (mDecorContentParent != null)) {
        mDecorContentParent.setMenuPrepared();
      }
      if ((menu != null) && (!refreshMenuContent)) {
        break label233;
      }
      if ((menu == null) && ((!initializePanelMenu(paramPanelFeatureState)) || (menu == null))) {
        break;
      }
      if ((i != 0) && (mDecorContentParent != null))
      {
        if (mActionMenuPresenterCallback == null) {
          mActionMenuPresenterCallback = new ActionMenuPresenterCallback(null);
        }
        mDecorContentParent.setMenu(menu, mActionMenuPresenterCallback);
      }
      menu.stopDispatchingItemsChanged();
      if (getWindowCallback().onCreatePanelMenu(featureId, menu)) {
        break label228;
      }
      paramPanelFeatureState.setMenu(null);
      if ((i == 0) || (mDecorContentParent == null)) {
        break;
      }
      mDecorContentParent.setMenu(null, mActionMenuPresenterCallback);
      return false;
    }
    label228:
    refreshMenuContent = false;
    label233:
    menu.stopDispatchingItemsChanged();
    if (frozenActionViewState != null)
    {
      menu.restoreActionViewStates(frozenActionViewState);
      frozenActionViewState = null;
    }
    if (!getWindowCallback().onPreparePanel(0, null, menu))
    {
      if ((i != 0) && (mDecorContentParent != null)) {
        mDecorContentParent.setMenu(null, mActionMenuPresenterCallback);
      }
      menu.startDispatchingItemsChanged();
      return false;
    }
    int j;
    if (paramKeyEvent != null)
    {
      j = paramKeyEvent.getDeviceId();
      if (KeyCharacterMap.load(j).getKeyboardType() == 1) {
        break label387;
      }
    }
    label387:
    for (boolean bool = true;; bool = false)
    {
      qwertyMode = bool;
      menu.setQwertyMode(qwertyMode);
      menu.startDispatchingItemsChanged();
      isPrepared = true;
      isHandled = false;
      mPreparedPanel = paramPanelFeatureState;
      return true;
      j = -1;
      break;
    }
  }
  
  private void reopenMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
  {
    if ((mDecorContentParent != null) && (mDecorContentParent.canShowOverflowMenu()) && ((!ViewConfigurationCompat.hasPermanentMenuKey(ViewConfiguration.get(mActivity))) || (mDecorContentParent.isOverflowMenuShowPending())))
    {
      WindowCallback localWindowCallback = getWindowCallback();
      if ((!mDecorContentParent.isOverflowMenuShowing()) || (!paramBoolean)) {
        if ((localWindowCallback != null) && (!isDestroyed()))
        {
          if ((mInvalidatePanelMenuPosted) && ((0x1 & mInvalidatePanelMenuFeatures) != 0))
          {
            mWindowDecor.removeCallbacks(mInvalidatePanelMenuRunnable);
            mInvalidatePanelMenuRunnable.run();
          }
          PanelFeatureState localPanelFeatureState2 = getPanelState(0, true);
          if ((menu != null) && (!refreshMenuContent) && (localWindowCallback.onPreparePanel(0, null, menu)))
          {
            localWindowCallback.onMenuOpened(8, menu);
            mDecorContentParent.showOverflowMenu();
          }
        }
      }
      do
      {
        return;
        mDecorContentParent.hideOverflowMenu();
      } while (isDestroyed());
      PanelFeatureState localPanelFeatureState3 = getPanelState(0, true);
      mActivity.onPanelClosed(8, menu);
      return;
    }
    PanelFeatureState localPanelFeatureState1 = getPanelState(0, true);
    refreshDecorView = true;
    closePanel(localPanelFeatureState1, false);
    openPanel(localPanelFeatureState1, null);
  }
  
  private void throwFeatureRequestIfSubDecorInstalled()
  {
    if (mSubDecorInstalled) {
      throw new AndroidRuntimeException("supportRequestWindowFeature() must be called before adding content");
    }
  }
  
  private int updateStatusGuard(int paramInt)
  {
    ActionBarContextView localActionBarContextView = mActionModeView;
    int i = 0;
    ViewGroup.MarginLayoutParams localMarginLayoutParams;
    int n;
    int m;
    if (localActionBarContextView != null)
    {
      boolean bool = mActionModeView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams;
      i = 0;
      if (bool)
      {
        localMarginLayoutParams = (ViewGroup.MarginLayoutParams)mActionModeView.getLayoutParams();
        if (!mActionModeView.isShown()) {
          break label325;
        }
        if (mTempRect1 == null)
        {
          mTempRect1 = new Rect();
          mTempRect2 = new Rect();
        }
        Rect localRect1 = mTempRect1;
        Rect localRect2 = mTempRect2;
        localRect1.set(0, paramInt, 0, 0);
        ViewUtils.computeFitSystemWindows(mSubDecor, localRect1, localRect2);
        if (top != 0) {
          break label278;
        }
        n = paramInt;
        int i1 = topMargin;
        m = 0;
        if (i1 != n)
        {
          m = 1;
          topMargin = paramInt;
          if (mStatusGuard != null) {
            break label284;
          }
          mStatusGuard = new View(mActivity);
          mStatusGuard.setBackgroundColor(mActivity.getResources().getColor(R.color.abc_input_method_navigation_guard));
          mSubDecor.addView(mStatusGuard, -1, new ViewGroup.LayoutParams(-1, paramInt));
        }
        label213:
        if (mStatusGuard == null) {
          break label320;
        }
        i = 1;
        label222:
        if ((!mOverlayActionMode) && (i != 0)) {
          paramInt = 0;
        }
        label235:
        if (m != 0) {
          mActionModeView.setLayoutParams(localMarginLayoutParams);
        }
      }
    }
    View localView;
    int j;
    if (mStatusGuard != null)
    {
      localView = mStatusGuard;
      j = 0;
      if (i == 0) {
        break label356;
      }
    }
    for (;;)
    {
      localView.setVisibility(j);
      return paramInt;
      label278:
      n = 0;
      break;
      label284:
      ViewGroup.LayoutParams localLayoutParams = mStatusGuard.getLayoutParams();
      if (height == paramInt) {
        break label213;
      }
      height = paramInt;
      mStatusGuard.setLayoutParams(localLayoutParams);
      break label213;
      label320:
      i = 0;
      break label222;
      label325:
      int k = topMargin;
      m = 0;
      i = 0;
      if (k == 0) {
        break label235;
      }
      m = 1;
      topMargin = 0;
      i = 0;
      break label235;
      label356:
      j = 8;
    }
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    ensureSubDecor();
    ((ViewGroup)mActivity.findViewById(16908290)).addView(paramView, paramLayoutParams);
    mActivity.onSupportContentChanged();
  }
  
  public ActionBar createSupportActionBar()
  {
    ensureSubDecor();
    WindowDecorActionBar localWindowDecorActionBar = new WindowDecorActionBar(mActivity, mOverlayActionBar);
    localWindowDecorActionBar.setDefaultDisplayHomeAsUpEnabled(mEnableDefaultActionBarUp);
    return localWindowDecorActionBar;
  }
  
  View createView(String paramString, @NonNull Context paramContext, @NonNull AttributeSet paramAttributeSet)
  {
    int i;
    if (Build.VERSION.SDK_INT < 21)
    {
      i = -1;
      switch (paramString.hashCode())
      {
      }
    }
    for (;;)
    {
      switch (i)
      {
      default: 
        return null;
        if (paramString.equals("EditText"))
        {
          i = 0;
          continue;
          if (paramString.equals("Spinner"))
          {
            i = 1;
            continue;
            if (paramString.equals("CheckBox"))
            {
              i = 2;
              continue;
              if (paramString.equals("RadioButton"))
              {
                i = 3;
                continue;
                if (paramString.equals("CheckedTextView")) {
                  i = 4;
                }
              }
            }
          }
        }
        break;
      }
    }
    return new TintEditText(paramContext, paramAttributeSet);
    return new TintSpinner(paramContext, paramAttributeSet);
    return new TintCheckBox(paramContext, paramAttributeSet);
    return new TintRadioButton(paramContext, paramAttributeSet);
    return new TintCheckedTextView(paramContext, paramAttributeSet);
  }
  
  final void ensureSubDecor()
  {
    Object localObject;
    if (!mSubDecorInstalled)
    {
      if (!mHasActionBar) {
        break label318;
      }
      TypedValue localTypedValue = new TypedValue();
      mActivity.getTheme().resolveAttribute(R.attr.actionBarTheme, localTypedValue, true);
      if (resourceId == 0) {
        break label310;
      }
      localObject = new ContextThemeWrapper(mActivity, resourceId);
      mSubDecor = ((ViewGroup)LayoutInflater.from((Context)localObject).inflate(R.layout.abc_screen_toolbar, null));
      mDecorContentParent = ((DecorContentParent)mSubDecor.findViewById(R.id.decor_content_parent));
      mDecorContentParent.setWindowCallback(getWindowCallback());
      if (mOverlayActionBar) {
        mDecorContentParent.initFeature(9);
      }
      if (mFeatureProgress) {
        mDecorContentParent.initFeature(2);
      }
      if (mFeatureIndeterminateProgress) {
        mDecorContentParent.initFeature(5);
      }
    }
    for (;;)
    {
      ViewUtils.makeOptionalFitsSystemWindows(mSubDecor);
      mActivity.superSetContentView(mSubDecor);
      View localView = mActivity.findViewById(16908290);
      localView.setId(-1);
      mActivity.findViewById(R.id.action_bar_activity_content).setId(16908290);
      if ((localView instanceof FrameLayout)) {
        ((FrameLayout)localView).setForeground(null);
      }
      if ((mTitleToSet != null) && (mDecorContentParent != null))
      {
        mDecorContentParent.setWindowTitle(mTitleToSet);
        mTitleToSet = null;
      }
      applyFixedSizeWindow();
      onSubDecorInstalled();
      mSubDecorInstalled = true;
      PanelFeatureState localPanelFeatureState = getPanelState(0, false);
      if ((!isDestroyed()) && ((localPanelFeatureState == null) || (menu == null))) {
        invalidatePanelMenu(8);
      }
      return;
      label310:
      localObject = mActivity;
      break;
      label318:
      if (mOverlayActionMode) {}
      for (mSubDecor = ((ViewGroup)LayoutInflater.from(mActivity).inflate(R.layout.abc_screen_simple_overlay_action_mode, null));; mSubDecor = ((ViewGroup)LayoutInflater.from(mActivity).inflate(R.layout.abc_screen_simple, null)))
      {
        if (Build.VERSION.SDK_INT < 21) {
          break label396;
        }
        ViewCompat.setOnApplyWindowInsetsListener(mSubDecor, new OnApplyWindowInsetsListener()
        {
          public WindowInsetsCompat onApplyWindowInsets(View paramAnonymousView, WindowInsetsCompat paramAnonymousWindowInsetsCompat)
          {
            int i = paramAnonymousWindowInsetsCompat.getSystemWindowInsetTop();
            int j = ActionBarActivityDelegateBase.this.updateStatusGuard(i);
            if (i != j) {
              paramAnonymousWindowInsetsCompat = paramAnonymousWindowInsetsCompat.replaceSystemWindowInsets(paramAnonymousWindowInsetsCompat.getSystemWindowInsetLeft(), j, paramAnonymousWindowInsetsCompat.getSystemWindowInsetRight(), paramAnonymousWindowInsetsCompat.getSystemWindowInsetBottom());
            }
            return paramAnonymousWindowInsetsCompat;
          }
        });
        break;
      }
      label396:
      ((FitWindowsViewGroup)mSubDecor).setOnFitSystemWindowsListener(new FitWindowsViewGroup.OnFitSystemWindowsListener()
      {
        public void onFitSystemWindows(Rect paramAnonymousRect)
        {
          top = ActionBarActivityDelegateBase.this.updateStatusGuard(top);
        }
      });
    }
  }
  
  int getHomeAsUpIndicatorAttrId()
  {
    return R.attr.homeAsUpIndicator;
  }
  
  public boolean onBackPressed()
  {
    if (mActionMode != null) {
      mActionMode.finish();
    }
    ActionBar localActionBar;
    do
    {
      return true;
      localActionBar = getSupportActionBar();
    } while ((localActionBar != null) && (localActionBar.collapseActionView()));
    return false;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    if ((mHasActionBar) && (mSubDecorInstalled))
    {
      ActionBar localActionBar = getSupportActionBar();
      if (localActionBar != null) {
        localActionBar.onConfigurationChanged(paramConfiguration);
      }
    }
  }
  
  public void onContentChanged() {}
  
  void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    mWindowDecor = ((ViewGroup)mActivity.getWindow().getDecorView());
    ActionBar localActionBar;
    if (NavUtils.getParentActivityName(mActivity) != null)
    {
      localActionBar = peekSupportActionBar();
      if (localActionBar == null) {
        mEnableDefaultActionBarUp = true;
      }
    }
    else
    {
      return;
    }
    localActionBar.setDefaultDisplayHomeAsUpEnabled(true);
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu)
  {
    if (paramInt != 0) {
      return getWindowCallback().onCreatePanelMenu(paramInt, paramMenu);
    }
    return false;
  }
  
  public View onCreatePanelView(int paramInt)
  {
    ActionMode localActionMode = mActionMode;
    View localView = null;
    if (localActionMode == null)
    {
      WindowCallback localWindowCallback = getWindowCallback();
      localView = null;
      if (localWindowCallback != null) {
        localView = localWindowCallback.onCreatePanelView(paramInt);
      }
      if ((localView == null) && (mToolbarListMenuPresenter == null))
      {
        PanelFeatureState localPanelFeatureState = getPanelState(paramInt, true);
        openPanel(localPanelFeatureState, null);
        if (isOpen) {
          localView = shownPanelView;
        }
      }
    }
    return localView;
  }
  
  boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    return onKeyShortcut(paramInt, paramKeyEvent);
  }
  
  boolean onKeyShortcut(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((mPreparedPanel != null) && (performPanelShortcut(mPreparedPanel, paramKeyEvent.getKeyCode(), paramKeyEvent, 1))) {
      if (mPreparedPanel != null) {
        mPreparedPanel.isHandled = true;
      }
    }
    boolean bool;
    do
    {
      return true;
      if (mPreparedPanel != null) {
        break;
      }
      PanelFeatureState localPanelFeatureState = getPanelState(0, true);
      preparePanel(localPanelFeatureState, paramKeyEvent);
      bool = performPanelShortcut(localPanelFeatureState, paramKeyEvent.getKeyCode(), paramKeyEvent, 1);
      isPrepared = false;
    } while (bool);
    return false;
  }
  
  public boolean onMenuItemSelected(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem)
  {
    WindowCallback localWindowCallback = getWindowCallback();
    if ((localWindowCallback != null) && (!isDestroyed()))
    {
      PanelFeatureState localPanelFeatureState = findMenuPanel(paramMenuBuilder.getRootMenu());
      if (localPanelFeatureState != null) {
        return localWindowCallback.onMenuItemSelected(featureId, paramMenuItem);
      }
    }
    return false;
  }
  
  public void onMenuModeChange(MenuBuilder paramMenuBuilder)
  {
    reopenMenu(paramMenuBuilder, true);
  }
  
  boolean onMenuOpened(int paramInt, Menu paramMenu)
  {
    if (paramInt == 8)
    {
      ActionBar localActionBar = getSupportActionBar();
      if (localActionBar != null) {
        localActionBar.dispatchMenuVisibilityChanged(true);
      }
      return true;
    }
    return mActivity.superOnMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu)
  {
    PanelFeatureState localPanelFeatureState = getPanelState(paramInt, false);
    if (localPanelFeatureState != null) {
      closePanel(localPanelFeatureState, false);
    }
    if (paramInt == 8)
    {
      localActionBar = getSupportActionBar();
      if (localActionBar != null) {
        localActionBar.dispatchMenuVisibilityChanged(false);
      }
    }
    while (isDestroyed())
    {
      ActionBar localActionBar;
      return;
    }
    mActivity.superOnPanelClosed(paramInt, paramMenu);
  }
  
  public void onPostResume()
  {
    ActionBar localActionBar = getSupportActionBar();
    if (localActionBar != null) {
      localActionBar.setShowHideAnimationEnabled(true);
    }
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu)
  {
    if (paramInt != 0) {
      return getWindowCallback().onPreparePanel(paramInt, paramView, paramMenu);
    }
    return false;
  }
  
  public void onStop()
  {
    ActionBar localActionBar = getSupportActionBar();
    if (localActionBar != null) {
      localActionBar.setShowHideAnimationEnabled(false);
    }
  }
  
  void onSubDecorInstalled() {}
  
  public void onTitleChanged(CharSequence paramCharSequence)
  {
    if (mDecorContentParent != null)
    {
      mDecorContentParent.setWindowTitle(paramCharSequence);
      return;
    }
    if (getSupportActionBar() != null)
    {
      getSupportActionBar().setWindowTitle(paramCharSequence);
      return;
    }
    mTitleToSet = paramCharSequence;
  }
  
  final boolean performPanelShortcut(PanelFeatureState paramPanelFeatureState, int paramInt1, KeyEvent paramKeyEvent, int paramInt2)
  {
    boolean bool1;
    if (paramKeyEvent.isSystem()) {
      bool1 = false;
    }
    do
    {
      return bool1;
      if (!isPrepared)
      {
        boolean bool2 = preparePanel(paramPanelFeatureState, paramKeyEvent);
        bool1 = false;
        if (!bool2) {}
      }
      else
      {
        MenuBuilder localMenuBuilder = menu;
        bool1 = false;
        if (localMenuBuilder != null) {
          bool1 = menu.performShortcut(paramInt1, paramKeyEvent, paramInt2);
        }
      }
    } while ((!bool1) || ((paramInt2 & 0x1) != 0) || (mDecorContentParent != null));
    closePanel(paramPanelFeatureState, true);
    return bool1;
  }
  
  public void setContentView(int paramInt)
  {
    ensureSubDecor();
    ViewGroup localViewGroup = (ViewGroup)mActivity.findViewById(16908290);
    localViewGroup.removeAllViews();
    mActivity.getLayoutInflater().inflate(paramInt, localViewGroup);
    mActivity.onSupportContentChanged();
  }
  
  public void setContentView(View paramView)
  {
    ensureSubDecor();
    ViewGroup localViewGroup = (ViewGroup)mActivity.findViewById(16908290);
    localViewGroup.removeAllViews();
    localViewGroup.addView(paramView);
    mActivity.onSupportContentChanged();
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams)
  {
    ensureSubDecor();
    ViewGroup localViewGroup = (ViewGroup)mActivity.findViewById(16908290);
    localViewGroup.removeAllViews();
    localViewGroup.addView(paramView, paramLayoutParams);
    mActivity.onSupportContentChanged();
  }
  
  void setSupportActionBar(Toolbar paramToolbar)
  {
    ActionBar localActionBar = getSupportActionBar();
    if ((localActionBar instanceof WindowDecorActionBar)) {
      throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
    }
    if ((localActionBar instanceof ToolbarActionBar)) {
      ((ToolbarActionBar)localActionBar).setListMenuPresenter(null);
    }
    ToolbarActionBar localToolbarActionBar = new ToolbarActionBar(paramToolbar, mActivity.getTitle(), mActivity.getWindow(), mDefaultWindowCallback);
    ensureToolbarListMenuPresenter();
    localToolbarActionBar.setListMenuPresenter(mToolbarListMenuPresenter);
    setSupportActionBar(localToolbarActionBar);
    setWindowCallback(localToolbarActionBar.getWrappedWindowCallback());
    localToolbarActionBar.invalidateOptionsMenu();
  }
  
  void setSupportProgress(int paramInt) {}
  
  void setSupportProgressBarIndeterminate(boolean paramBoolean) {}
  
  void setSupportProgressBarIndeterminateVisibility(boolean paramBoolean) {}
  
  void setSupportProgressBarVisibility(boolean paramBoolean) {}
  
  public ActionMode startSupportActionMode(ActionMode.Callback paramCallback)
  {
    if (paramCallback == null) {
      throw new IllegalArgumentException("ActionMode callback can not be null.");
    }
    if (mActionMode != null) {
      mActionMode.finish();
    }
    ActionModeCallbackWrapper localActionModeCallbackWrapper = new ActionModeCallbackWrapper(paramCallback);
    ActionBar localActionBar = getSupportActionBar();
    if (localActionBar != null)
    {
      mActionMode = localActionBar.startActionMode(localActionModeCallbackWrapper);
      if (mActionMode != null) {
        mActivity.onSupportActionModeStarted(mActionMode);
      }
    }
    if (mActionMode == null) {
      mActionMode = startSupportActionModeFromWindow(localActionModeCallbackWrapper);
    }
    return mActionMode;
  }
  
  ActionMode startSupportActionModeFromWindow(ActionMode.Callback paramCallback)
  {
    if (mActionMode != null) {
      mActionMode.finish();
    }
    ActionModeCallbackWrapper localActionModeCallbackWrapper = new ActionModeCallbackWrapper(paramCallback);
    Context localContext = getActionBarThemedContext();
    boolean bool;
    if (mActionModeView == null)
    {
      if (mIsFloating)
      {
        mActionModeView = new ActionBarContextView(localContext);
        mActionModePopup = new PopupWindow(localContext, null, R.attr.actionModePopupWindowStyle);
        mActionModePopup.setContentView(mActionModeView);
        mActionModePopup.setWidth(-1);
        TypedValue localTypedValue = new TypedValue();
        mActivity.getTheme().resolveAttribute(R.attr.actionBarSize, localTypedValue, true);
        int i = TypedValue.complexToDimensionPixelSize(data, mActivity.getResources().getDisplayMetrics());
        mActionModeView.setContentHeight(i);
        mActionModePopup.setHeight(-2);
        mShowActionModePopup = new Runnable()
        {
          public void run()
          {
            mActionModePopup.showAtLocation(mActionModeView, 55, 0, 0);
          }
        };
      }
    }
    else if (mActionModeView != null)
    {
      mActionModeView.killMode();
      ActionBarContextView localActionBarContextView = mActionModeView;
      if (mActionModePopup != null) {
        break label386;
      }
      bool = true;
      label196:
      StandaloneActionMode localStandaloneActionMode = new StandaloneActionMode(localContext, localActionBarContextView, localActionModeCallbackWrapper, bool);
      if (!paramCallback.onCreateActionMode(localStandaloneActionMode, localStandaloneActionMode.getMenu())) {
        break label392;
      }
      localStandaloneActionMode.invalidate();
      mActionModeView.initForMode(localStandaloneActionMode);
      mActionModeView.setVisibility(0);
      mActionMode = localStandaloneActionMode;
      if (mActionModePopup != null) {
        mActivity.getWindow().getDecorView().post(mShowActionModePopup);
      }
      mActionModeView.sendAccessibilityEvent(32);
      if (mActionModeView.getParent() != null) {
        ViewCompat.requestApplyInsets((View)mActionModeView.getParent());
      }
    }
    for (;;)
    {
      if ((mActionMode != null) && (mActivity != null)) {
        mActivity.onSupportActionModeStarted(mActionMode);
      }
      return mActionMode;
      ViewStubCompat localViewStubCompat = (ViewStubCompat)mActivity.findViewById(R.id.action_mode_bar_stub);
      if (localViewStubCompat == null) {
        break;
      }
      localViewStubCompat.setLayoutInflater(LayoutInflater.from(localContext));
      mActionModeView = ((ActionBarContextView)localViewStubCompat.inflate());
      break;
      label386:
      bool = false;
      break label196;
      label392:
      mActionMode = null;
    }
  }
  
  public void supportInvalidateOptionsMenu()
  {
    ActionBar localActionBar = getSupportActionBar();
    if ((localActionBar != null) && (localActionBar.invalidateOptionsMenu())) {
      return;
    }
    invalidatePanelMenu(0);
  }
  
  public boolean supportRequestWindowFeature(int paramInt)
  {
    switch (paramInt)
    {
    case 3: 
    case 4: 
    case 6: 
    case 7: 
    default: 
      return mActivity.requestWindowFeature(paramInt);
    case 8: 
      throwFeatureRequestIfSubDecorInstalled();
      mHasActionBar = true;
      return true;
    case 9: 
      throwFeatureRequestIfSubDecorInstalled();
      mOverlayActionBar = true;
      return true;
    case 10: 
      throwFeatureRequestIfSubDecorInstalled();
      mOverlayActionMode = true;
      return true;
    case 2: 
      throwFeatureRequestIfSubDecorInstalled();
      mFeatureProgress = true;
      return true;
    }
    throwFeatureRequestIfSubDecorInstalled();
    mFeatureIndeterminateProgress = true;
    return true;
  }
  
  private final class ActionMenuPresenterCallback
    implements MenuPresenter.Callback
  {
    private ActionMenuPresenterCallback() {}
    
    public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
    {
      ActionBarActivityDelegateBase.this.checkCloseActionMenu(paramMenuBuilder);
    }
    
    public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder)
    {
      WindowCallback localWindowCallback = getWindowCallback();
      if (localWindowCallback != null) {
        localWindowCallback.onMenuOpened(8, paramMenuBuilder);
      }
      return true;
    }
  }
  
  private class ActionModeCallbackWrapper
    implements ActionMode.Callback
  {
    private ActionMode.Callback mWrapped;
    
    public ActionModeCallbackWrapper(ActionMode.Callback paramCallback)
    {
      mWrapped = paramCallback;
    }
    
    public boolean onActionItemClicked(ActionMode paramActionMode, MenuItem paramMenuItem)
    {
      return mWrapped.onActionItemClicked(paramActionMode, paramMenuItem);
    }
    
    public boolean onCreateActionMode(ActionMode paramActionMode, Menu paramMenu)
    {
      return mWrapped.onCreateActionMode(paramActionMode, paramMenu);
    }
    
    public void onDestroyActionMode(ActionMode paramActionMode)
    {
      mWrapped.onDestroyActionMode(paramActionMode);
      if (mActionModePopup != null)
      {
        mActivity.getWindow().getDecorView().removeCallbacks(mShowActionModePopup);
        mActionModePopup.dismiss();
      }
      for (;;)
      {
        if (mActionModeView != null) {
          mActionModeView.removeAllViews();
        }
        if (mActivity != null) {}
        try
        {
          mActivity.onSupportActionModeFinished(mActionMode);
          mActionMode = null;
          return;
          if (mActionModeView == null) {
            continue;
          }
          mActionModeView.setVisibility(8);
          if (mActionModeView.getParent() == null) {
            continue;
          }
          ViewCompat.requestApplyInsets((View)mActionModeView.getParent());
        }
        catch (AbstractMethodError localAbstractMethodError)
        {
          for (;;) {}
        }
      }
    }
    
    public boolean onPrepareActionMode(ActionMode paramActionMode, Menu paramMenu)
    {
      return mWrapped.onPrepareActionMode(paramActionMode, paramMenu);
    }
  }
  
  private static final class PanelFeatureState
  {
    ViewGroup decorView;
    int featureId;
    Bundle frozenActionViewState;
    Bundle frozenMenuState;
    boolean isHandled;
    boolean isOpen;
    boolean isPrepared;
    ListMenuPresenter listMenuPresenter;
    Context listPresenterContext;
    MenuBuilder menu;
    public boolean qwertyMode;
    boolean refreshDecorView;
    boolean refreshMenuContent;
    View shownPanelView;
    boolean wasLastOpen;
    
    PanelFeatureState(int paramInt)
    {
      featureId = paramInt;
      refreshDecorView = false;
    }
    
    void applyFrozenState()
    {
      if ((menu != null) && (frozenMenuState != null))
      {
        menu.restorePresenterStates(frozenMenuState);
        frozenMenuState = null;
      }
    }
    
    public void clearMenuPresenters()
    {
      if (menu != null) {
        menu.removeMenuPresenter(listMenuPresenter);
      }
      listMenuPresenter = null;
    }
    
    MenuView getListMenuView(MenuPresenter.Callback paramCallback)
    {
      if (menu == null) {
        return null;
      }
      if (listMenuPresenter == null)
      {
        listMenuPresenter = new ListMenuPresenter(listPresenterContext, R.layout.abc_list_menu_item_layout);
        listMenuPresenter.setCallback(paramCallback);
        menu.addMenuPresenter(listMenuPresenter);
      }
      return listMenuPresenter.getMenuView(decorView);
    }
    
    public boolean hasPanelItems()
    {
      if (shownPanelView == null) {}
      while (listMenuPresenter.getAdapter().getCount() <= 0) {
        return false;
      }
      return true;
    }
    
    void onRestoreInstanceState(Parcelable paramParcelable)
    {
      SavedState localSavedState = (SavedState)paramParcelable;
      featureId = featureId;
      wasLastOpen = isOpen;
      frozenMenuState = menuState;
      shownPanelView = null;
      decorView = null;
    }
    
    Parcelable onSaveInstanceState()
    {
      SavedState localSavedState = new SavedState(null);
      featureId = featureId;
      isOpen = isOpen;
      if (menu != null)
      {
        menuState = new Bundle();
        menu.savePresenterStates(menuState);
      }
      return localSavedState;
    }
    
    void setMenu(MenuBuilder paramMenuBuilder)
    {
      if (paramMenuBuilder == menu) {}
      do
      {
        return;
        if (menu != null) {
          menu.removeMenuPresenter(listMenuPresenter);
        }
        menu = paramMenuBuilder;
      } while ((paramMenuBuilder == null) || (listMenuPresenter == null));
      paramMenuBuilder.addMenuPresenter(listMenuPresenter);
    }
    
    void setStyle(Context paramContext)
    {
      TypedValue localTypedValue = new TypedValue();
      Resources.Theme localTheme = paramContext.getResources().newTheme();
      localTheme.setTo(paramContext.getTheme());
      localTheme.resolveAttribute(R.attr.actionBarPopupTheme, localTypedValue, true);
      if (resourceId != 0) {
        localTheme.applyStyle(resourceId, true);
      }
      localTheme.resolveAttribute(R.attr.panelMenuListTheme, localTypedValue, true);
      if (resourceId != 0) {
        localTheme.applyStyle(resourceId, true);
      }
      for (;;)
      {
        ContextThemeWrapper localContextThemeWrapper = new ContextThemeWrapper(paramContext, 0);
        localContextThemeWrapper.getTheme().setTo(localTheme);
        listPresenterContext = localContextThemeWrapper;
        return;
        localTheme.applyStyle(R.style.Theme_AppCompat_CompactMenu, true);
      }
    }
    
    private static class SavedState
      implements Parcelable
    {
      public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator()
      {
        public ActionBarActivityDelegateBase.PanelFeatureState.SavedState createFromParcel(Parcel paramAnonymousParcel)
        {
          return ActionBarActivityDelegateBase.PanelFeatureState.SavedState.readFromParcel(paramAnonymousParcel);
        }
        
        public ActionBarActivityDelegateBase.PanelFeatureState.SavedState[] newArray(int paramAnonymousInt)
        {
          return new ActionBarActivityDelegateBase.PanelFeatureState.SavedState[paramAnonymousInt];
        }
      };
      int featureId;
      boolean isOpen;
      Bundle menuState;
      
      private SavedState() {}
      
      private static SavedState readFromParcel(Parcel paramParcel)
      {
        int i = 1;
        SavedState localSavedState = new SavedState();
        featureId = paramParcel.readInt();
        if (paramParcel.readInt() == i) {}
        for (;;)
        {
          isOpen = i;
          if (isOpen) {
            menuState = paramParcel.readBundle();
          }
          return localSavedState;
          i = 0;
        }
      }
      
      public int describeContents()
      {
        return 0;
      }
      
      public void writeToParcel(Parcel paramParcel, int paramInt)
      {
        paramParcel.writeInt(featureId);
        if (isOpen) {}
        for (int i = 1;; i = 0)
        {
          paramParcel.writeInt(i);
          if (isOpen) {
            paramParcel.writeBundle(menuState);
          }
          return;
        }
      }
    }
  }
  
  private final class PanelMenuPresenterCallback
    implements MenuPresenter.Callback
  {
    private PanelMenuPresenterCallback() {}
    
    public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
    {
      MenuBuilder localMenuBuilder = paramMenuBuilder.getRootMenu();
      if (localMenuBuilder != paramMenuBuilder) {}
      ActionBarActivityDelegateBase.PanelFeatureState localPanelFeatureState;
      for (int i = 1;; i = 0)
      {
        ActionBarActivityDelegateBase localActionBarActivityDelegateBase = ActionBarActivityDelegateBase.this;
        if (i != 0) {
          paramMenuBuilder = localMenuBuilder;
        }
        localPanelFeatureState = localActionBarActivityDelegateBase.findMenuPanel(paramMenuBuilder);
        if (localPanelFeatureState != null)
        {
          if (i == 0) {
            break;
          }
          ActionBarActivityDelegateBase.this.callOnPanelClosed(featureId, localPanelFeatureState, localMenuBuilder);
          ActionBarActivityDelegateBase.this.closePanel(localPanelFeatureState, true);
        }
        return;
      }
      mActivity.closeOptionsMenu();
      ActionBarActivityDelegateBase.this.closePanel(localPanelFeatureState, paramBoolean);
    }
    
    public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder)
    {
      if ((paramMenuBuilder == null) && (mHasActionBar))
      {
        WindowCallback localWindowCallback = getWindowCallback();
        if ((localWindowCallback != null) && (!isDestroyed())) {
          localWindowCallback.onMenuOpened(8, paramMenuBuilder);
        }
      }
      return true;
    }
  }
}
