package android.support.v7.app;

import android.content.Context;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v7.appcompat.R.attr;
import android.support.v7.appcompat.R.style;
import android.support.v7.appcompat.R.styleable;

abstract class DrawerArrowDrawable
  extends Drawable
{
  private static final float ARROW_HEAD_ANGLE = (float)Math.toRadians(45.0D);
  private final float mBarGap;
  private final float mBarSize;
  private final float mBarThickness;
  private final float mMiddleArrowSize;
  private final Paint mPaint = new Paint();
  private final Path mPath = new Path();
  private float mProgress;
  private final int mSize;
  private final boolean mSpin;
  private final float mTopBottomArrowSize;
  private boolean mVerticalMirror = false;
  
  DrawerArrowDrawable(Context paramContext)
  {
    TypedArray localTypedArray = paramContext.getTheme().obtainStyledAttributes(null, R.styleable.DrawerArrowToggle, R.attr.drawerArrowStyle, R.style.Base_Widget_AppCompat_DrawerArrowToggle);
    mPaint.setAntiAlias(true);
    mPaint.setColor(localTypedArray.getColor(R.styleable.DrawerArrowToggle_color, 0));
    mSize = localTypedArray.getDimensionPixelSize(R.styleable.DrawerArrowToggle_drawableSize, 0);
    mBarSize = localTypedArray.getDimension(R.styleable.DrawerArrowToggle_barSize, 0.0F);
    mTopBottomArrowSize = localTypedArray.getDimension(R.styleable.DrawerArrowToggle_topBottomBarArrowSize, 0.0F);
    mBarThickness = localTypedArray.getDimension(R.styleable.DrawerArrowToggle_thickness, 0.0F);
    mBarGap = localTypedArray.getDimension(R.styleable.DrawerArrowToggle_gapBetweenBars, 0.0F);
    mSpin = localTypedArray.getBoolean(R.styleable.DrawerArrowToggle_spinBars, true);
    mMiddleArrowSize = localTypedArray.getDimension(R.styleable.DrawerArrowToggle_middleBarArrowSize, 0.0F);
    localTypedArray.recycle();
    mPaint.setStyle(Paint.Style.STROKE);
    mPaint.setStrokeJoin(Paint.Join.ROUND);
    mPaint.setStrokeCap(Paint.Cap.SQUARE);
    mPaint.setStrokeWidth(mBarThickness);
  }
  
  private static float lerp(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    return paramFloat1 + paramFloat3 * (paramFloat2 - paramFloat1);
  }
  
  public void draw(Canvas paramCanvas)
  {
    Rect localRect = getBounds();
    boolean bool = isLayoutRtl();
    float f1 = lerp(mBarSize, mTopBottomArrowSize, mProgress);
    float f2 = lerp(mBarSize, mMiddleArrowSize, mProgress);
    float f3 = lerp(0.0F, mBarThickness / 2.0F, mProgress);
    float f4 = lerp(0.0F, ARROW_HEAD_ANGLE, mProgress);
    float f5;
    float f6;
    label88:
    int i;
    if (bool)
    {
      f5 = 0.0F;
      if (!bool) {
        break label336;
      }
      f6 = 180.0F;
      float f7 = lerp(f5, f6, mProgress);
      float f8 = lerp(mBarGap + mBarThickness, 0.0F, mProgress);
      mPath.rewind();
      float f9 = -f2 / 2.0F;
      mPath.moveTo(f9 + f3, 0.0F);
      mPath.rLineTo(f2 - f3, 0.0F);
      float f10 = (float)Math.round(f1 * Math.cos(f4));
      float f11 = (float)Math.round(f1 * Math.sin(f4));
      mPath.moveTo(f9, f8);
      mPath.rLineTo(f10, f11);
      mPath.moveTo(f9, -f8);
      mPath.rLineTo(f10, -f11);
      mPath.moveTo(0.0F, 0.0F);
      mPath.close();
      paramCanvas.save();
      if (!mSpin) {
        break label348;
      }
      if (!(bool ^ mVerticalMirror)) {
        break label342;
      }
      i = -1;
      label278:
      paramCanvas.rotate(f7 * i, localRect.centerX(), localRect.centerY());
    }
    for (;;)
    {
      paramCanvas.translate(localRect.centerX(), localRect.centerY());
      paramCanvas.drawPath(mPath, mPaint);
      paramCanvas.restore();
      return;
      f5 = -180.0F;
      break;
      label336:
      f6 = 0.0F;
      break label88;
      label342:
      i = 1;
      break label278;
      label348:
      if (bool) {
        paramCanvas.rotate(180.0F, localRect.centerX(), localRect.centerY());
      }
    }
  }
  
  public int getIntrinsicHeight()
  {
    return mSize;
  }
  
  public int getIntrinsicWidth()
  {
    return mSize;
  }
  
  public int getOpacity()
  {
    return -3;
  }
  
  public float getProgress()
  {
    return mProgress;
  }
  
  public boolean isAutoMirrored()
  {
    return true;
  }
  
  abstract boolean isLayoutRtl();
  
  public void setAlpha(int paramInt)
  {
    mPaint.setAlpha(paramInt);
  }
  
  public void setColorFilter(ColorFilter paramColorFilter)
  {
    mPaint.setColorFilter(paramColorFilter);
  }
  
  public void setProgress(float paramFloat)
  {
    mProgress = paramFloat;
    invalidateSelf();
  }
  
  protected void setVerticalMirror(boolean paramBoolean)
  {
    mVerticalMirror = paramBoolean;
  }
}
