package android.support.v4.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.Parcelable;
import android.view.View;
import android.widget.ImageView;
import java.util.List;
import java.util.Map;

public abstract class SharedElementCallback
{
  private Matrix mTempMatrix;
  
  public SharedElementCallback() {}
  
  public Parcelable onCaptureSharedElementSnapshot(View paramView, Matrix paramMatrix, RectF paramRectF)
  {
    int i = Math.round(paramRectF.width());
    int j = Math.round(paramRectF.height());
    Bitmap localBitmap = null;
    if (i > 0)
    {
      localBitmap = null;
      if (j > 0)
      {
        if (mTempMatrix == null) {
          mTempMatrix = new Matrix();
        }
        mTempMatrix.set(paramMatrix);
        mTempMatrix.postTranslate(-left, -top);
        localBitmap = Bitmap.createBitmap(i, j, Bitmap.Config.ARGB_8888);
        Canvas localCanvas = new Canvas(localBitmap);
        localCanvas.concat(mTempMatrix);
        paramView.draw(localCanvas);
      }
    }
    return localBitmap;
  }
  
  public View onCreateSnapshotView(Context paramContext, Parcelable paramParcelable)
  {
    boolean bool = paramParcelable instanceof Bitmap;
    ImageView localImageView = null;
    if (bool)
    {
      Bitmap localBitmap = (Bitmap)paramParcelable;
      localImageView = new ImageView(paramContext);
      localImageView.setImageBitmap(localBitmap);
    }
    return localImageView;
  }
  
  public void onMapSharedElements(List<String> paramList, Map<String, View> paramMap) {}
  
  public void onRejectSharedElements(List<View> paramList) {}
  
  public void onSharedElementEnd(List<String> paramList, List<View> paramList1, List<View> paramList2) {}
  
  public void onSharedElementStart(List<String> paramList, List<View> paramList1, List<View> paramList2) {}
}
