package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.annotation.Nullable;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.MarginLayoutParamsCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.ActionBar.LayoutParams;
import android.support.v7.appcompat.R.attr;
import android.support.v7.appcompat.R.styleable;
import android.support.v7.internal.view.SupportMenuInflater;
import android.support.v7.internal.view.menu.MenuBuilder;
import android.support.v7.internal.view.menu.MenuBuilder.Callback;
import android.support.v7.internal.view.menu.MenuItemImpl;
import android.support.v7.internal.view.menu.MenuPresenter;
import android.support.v7.internal.view.menu.MenuPresenter.Callback;
import android.support.v7.internal.view.menu.MenuView;
import android.support.v7.internal.view.menu.SubMenuBuilder;
import android.support.v7.internal.widget.DecorToolbar;
import android.support.v7.internal.widget.RtlSpacingHelper;
import android.support.v7.internal.widget.TintManager;
import android.support.v7.internal.widget.TintTypedArray;
import android.support.v7.internal.widget.ToolbarWidgetWrapper;
import android.support.v7.internal.widget.ViewUtils;
import android.support.v7.view.CollapsibleActionView;
import android.text.Layout;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class Toolbar
  extends ViewGroup
{
  private static final String TAG = "Toolbar";
  private MenuPresenter.Callback mActionMenuPresenterCallback;
  private int mButtonGravity;
  private ImageButton mCollapseButtonView;
  private CharSequence mCollapseDescription;
  private Drawable mCollapseIcon;
  private boolean mCollapsible;
  private final RtlSpacingHelper mContentInsets = new RtlSpacingHelper();
  private boolean mEatingTouch;
  View mExpandedActionView;
  private ExpandedActionViewMenuPresenter mExpandedMenuPresenter;
  private int mGravity = 8388627;
  private ImageView mLogoView;
  private int mMaxButtonHeight;
  private MenuBuilder.Callback mMenuBuilderCallback;
  private ActionMenuView mMenuView;
  private final ActionMenuView.OnMenuItemClickListener mMenuViewItemClickListener;
  private int mMinHeight;
  private ImageButton mNavButtonView;
  private OnMenuItemClickListener mOnMenuItemClickListener;
  private ActionMenuPresenter mOuterActionMenuPresenter;
  private Context mPopupContext;
  private int mPopupTheme;
  private final Runnable mShowOverflowMenuRunnable;
  private CharSequence mSubtitleText;
  private int mSubtitleTextAppearance;
  private int mSubtitleTextColor;
  private TextView mSubtitleTextView;
  private final int[] mTempMargins = new int[2];
  private final ArrayList<View> mTempViews = new ArrayList();
  private final TintManager mTintManager;
  private int mTitleMarginBottom;
  private int mTitleMarginEnd;
  private int mTitleMarginStart;
  private int mTitleMarginTop;
  private CharSequence mTitleText;
  private int mTitleTextAppearance;
  private int mTitleTextColor;
  private TextView mTitleTextView;
  private ToolbarWidgetWrapper mWrapper;
  
  public Toolbar(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, R.attr.toolbarStyle);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(themifyContext(paramContext, paramAttributeSet, paramInt), paramAttributeSet, paramInt);
    ActionMenuView.OnMenuItemClickListener local1 = new ActionMenuView.OnMenuItemClickListener()
    {
      public boolean onMenuItemClick(MenuItem paramAnonymousMenuItem)
      {
        if (mOnMenuItemClickListener != null) {
          return mOnMenuItemClickListener.onMenuItemClick(paramAnonymousMenuItem);
        }
        return false;
      }
    };
    mMenuViewItemClickListener = local1;
    Runnable local2 = new Runnable()
    {
      public void run()
      {
        showOverflowMenu();
      }
    };
    mShowOverflowMenuRunnable = local2;
    TintTypedArray localTintTypedArray = TintTypedArray.obtainStyledAttributes(getContext(), paramAttributeSet, R.styleable.Toolbar, paramInt, 0);
    mTitleTextAppearance = localTintTypedArray.getResourceId(R.styleable.Toolbar_titleTextAppearance, 0);
    mSubtitleTextAppearance = localTintTypedArray.getResourceId(R.styleable.Toolbar_subtitleTextAppearance, 0);
    mGravity = localTintTypedArray.getInteger(R.styleable.Toolbar_android_gravity, mGravity);
    mButtonGravity = 48;
    int i = localTintTypedArray.getDimensionPixelOffset(R.styleable.Toolbar_titleMargins, 0);
    mTitleMarginBottom = i;
    mTitleMarginTop = i;
    mTitleMarginEnd = i;
    mTitleMarginStart = i;
    int j = localTintTypedArray.getDimensionPixelOffset(R.styleable.Toolbar_titleMarginStart, -1);
    if (j >= 0) {
      mTitleMarginStart = j;
    }
    int k = localTintTypedArray.getDimensionPixelOffset(R.styleable.Toolbar_titleMarginEnd, -1);
    if (k >= 0) {
      mTitleMarginEnd = k;
    }
    int m = localTintTypedArray.getDimensionPixelOffset(R.styleable.Toolbar_titleMarginTop, -1);
    if (m >= 0) {
      mTitleMarginTop = m;
    }
    int n = localTintTypedArray.getDimensionPixelOffset(R.styleable.Toolbar_titleMarginBottom, -1);
    if (n >= 0) {
      mTitleMarginBottom = n;
    }
    mMaxButtonHeight = localTintTypedArray.getDimensionPixelSize(R.styleable.Toolbar_maxButtonHeight, -1);
    int i1 = localTintTypedArray.getDimensionPixelOffset(R.styleable.Toolbar_contentInsetStart, Integer.MIN_VALUE);
    int i2 = localTintTypedArray.getDimensionPixelOffset(R.styleable.Toolbar_contentInsetEnd, Integer.MIN_VALUE);
    int i3 = localTintTypedArray.getDimensionPixelSize(R.styleable.Toolbar_contentInsetLeft, 0);
    int i4 = localTintTypedArray.getDimensionPixelSize(R.styleable.Toolbar_contentInsetRight, 0);
    mContentInsets.setAbsolute(i3, i4);
    if ((i1 != Integer.MIN_VALUE) || (i2 != Integer.MIN_VALUE)) {
      mContentInsets.setRelative(i1, i2);
    }
    mCollapseIcon = localTintTypedArray.getDrawable(R.styleable.Toolbar_collapseIcon);
    mCollapseDescription = localTintTypedArray.getText(R.styleable.Toolbar_collapseContentDescription);
    CharSequence localCharSequence1 = localTintTypedArray.getText(R.styleable.Toolbar_title);
    if (!TextUtils.isEmpty(localCharSequence1)) {
      setTitle(localCharSequence1);
    }
    CharSequence localCharSequence2 = localTintTypedArray.getText(R.styleable.Toolbar_subtitle);
    if (!TextUtils.isEmpty(localCharSequence2)) {
      setSubtitle(localCharSequence2);
    }
    mPopupContext = getContext();
    setPopupTheme(localTintTypedArray.getResourceId(R.styleable.Toolbar_popupTheme, 0));
    Drawable localDrawable = localTintTypedArray.getDrawable(R.styleable.Toolbar_navigationIcon);
    if (localDrawable != null) {
      setNavigationIcon(localDrawable);
    }
    CharSequence localCharSequence3 = localTintTypedArray.getText(R.styleable.Toolbar_navigationContentDescription);
    if (!TextUtils.isEmpty(localCharSequence3)) {
      setNavigationContentDescription(localCharSequence3);
    }
    mMinHeight = localTintTypedArray.getDimensionPixelSize(R.styleable.Toolbar_android_minHeight, 0);
    localTintTypedArray.recycle();
    mTintManager = localTintTypedArray.getTintManager();
  }
  
  private void addCustomViewsWithGravity(List<View> paramList, int paramInt)
  {
    int i = 1;
    if (ViewCompat.getLayoutDirection(this) == i) {}
    int j;
    int k;
    for (;;)
    {
      j = getChildCount();
      k = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection(this));
      paramList.clear();
      if (i == 0) {
        break;
      }
      for (int n = j - 1; n >= 0; n--)
      {
        View localView2 = getChildAt(n);
        LayoutParams localLayoutParams2 = (LayoutParams)localView2.getLayoutParams();
        if ((mViewType == 0) && (shouldLayout(localView2)) && (getChildHorizontalGravity(gravity) == k)) {
          paramList.add(localView2);
        }
      }
      i = 0;
    }
    for (int m = 0; m < j; m++)
    {
      View localView1 = getChildAt(m);
      LayoutParams localLayoutParams1 = (LayoutParams)localView1.getLayoutParams();
      if ((mViewType == 0) && (shouldLayout(localView1)) && (getChildHorizontalGravity(gravity) == k)) {
        paramList.add(localView1);
      }
    }
  }
  
  private void addSystemView(View paramView)
  {
    ViewGroup.LayoutParams localLayoutParams = paramView.getLayoutParams();
    LayoutParams localLayoutParams1;
    if (localLayoutParams == null) {
      localLayoutParams1 = generateDefaultLayoutParams();
    }
    for (;;)
    {
      mViewType = 1;
      addView(paramView, localLayoutParams1);
      return;
      if (!checkLayoutParams(localLayoutParams)) {
        localLayoutParams1 = generateLayoutParams(localLayoutParams);
      } else {
        localLayoutParams1 = (LayoutParams)localLayoutParams;
      }
    }
  }
  
  private void ensureCollapseButtonView()
  {
    if (mCollapseButtonView == null)
    {
      mCollapseButtonView = new ImageButton(getContext(), null, R.attr.toolbarNavigationButtonStyle);
      mCollapseButtonView.setImageDrawable(mCollapseIcon);
      mCollapseButtonView.setContentDescription(mCollapseDescription);
      LayoutParams localLayoutParams = generateDefaultLayoutParams();
      gravity = (0x800003 | 0x70 & mButtonGravity);
      mViewType = 2;
      mCollapseButtonView.setLayoutParams(localLayoutParams);
      mCollapseButtonView.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          collapseActionView();
        }
      });
    }
  }
  
  private void ensureLogoView()
  {
    if (mLogoView == null) {
      mLogoView = new ImageView(getContext());
    }
  }
  
  private void ensureMenu()
  {
    ensureMenuView();
    if (mMenuView.peekMenu() == null)
    {
      MenuBuilder localMenuBuilder = (MenuBuilder)mMenuView.getMenu();
      if (mExpandedMenuPresenter == null) {
        mExpandedMenuPresenter = new ExpandedActionViewMenuPresenter(null);
      }
      mMenuView.setExpandedActionViewsExclusive(true);
      localMenuBuilder.addMenuPresenter(mExpandedMenuPresenter, mPopupContext);
    }
  }
  
  private void ensureMenuView()
  {
    if (mMenuView == null)
    {
      mMenuView = new ActionMenuView(getContext());
      mMenuView.setPopupTheme(mPopupTheme);
      mMenuView.setOnMenuItemClickListener(mMenuViewItemClickListener);
      mMenuView.setMenuCallbacks(mActionMenuPresenterCallback, mMenuBuilderCallback);
      LayoutParams localLayoutParams = generateDefaultLayoutParams();
      gravity = (0x800005 | 0x70 & mButtonGravity);
      mMenuView.setLayoutParams(localLayoutParams);
      addSystemView(mMenuView);
    }
  }
  
  private void ensureNavButtonView()
  {
    if (mNavButtonView == null)
    {
      mNavButtonView = new ImageButton(getContext(), null, R.attr.toolbarNavigationButtonStyle);
      LayoutParams localLayoutParams = generateDefaultLayoutParams();
      gravity = (0x800003 | 0x70 & mButtonGravity);
      mNavButtonView.setLayoutParams(localLayoutParams);
    }
  }
  
  private int getChildHorizontalGravity(int paramInt)
  {
    int i = ViewCompat.getLayoutDirection(this);
    int j = 0x7 & GravityCompat.getAbsoluteGravity(paramInt, i);
    switch (j)
    {
    case 2: 
    case 4: 
    default: 
      if (i != 1) {
        break;
      }
    }
    for (int k = 5;; k = 3)
    {
      j = k;
      return j;
    }
  }
  
  private int getChildTop(View paramView, int paramInt)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = paramView.getMeasuredHeight();
    int j;
    int k;
    int m;
    int n;
    int i1;
    if (paramInt > 0)
    {
      j = (i - paramInt) / 2;
      switch (getChildVerticalGravity(gravity))
      {
      default: 
        k = getPaddingTop();
        m = getPaddingBottom();
        n = getHeight();
        i1 = (n - k - m - i) / 2;
        if (i1 < topMargin) {
          i1 = topMargin;
        }
        break;
      }
    }
    for (;;)
    {
      return k + i1;
      j = 0;
      break;
      return getPaddingTop() - j;
      return getHeight() - getPaddingBottom() - i - bottomMargin - j;
      int i2 = n - m - i - i1 - k;
      if (i2 < bottomMargin) {
        i1 = Math.max(0, i1 - (bottomMargin - i2));
      }
    }
  }
  
  private int getChildVerticalGravity(int paramInt)
  {
    int i = paramInt & 0x70;
    switch (i)
    {
    default: 
      i = 0x70 & mGravity;
    }
    return i;
  }
  
  private int getHorizontalMargins(View paramView)
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return MarginLayoutParamsCompat.getMarginStart(localMarginLayoutParams) + MarginLayoutParamsCompat.getMarginEnd(localMarginLayoutParams);
  }
  
  private MenuInflater getMenuInflater()
  {
    return new SupportMenuInflater(getContext());
  }
  
  private int getMinimumHeightCompat()
  {
    if (Build.VERSION.SDK_INT >= 16) {
      return ViewCompat.getMinimumHeight(this);
    }
    return mMinHeight;
  }
  
  private int getVerticalMargins(View paramView)
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return topMargin + bottomMargin;
  }
  
  private int getViewListMeasuredWidth(List<View> paramList, int[] paramArrayOfInt)
  {
    int i = paramArrayOfInt[0];
    int j = paramArrayOfInt[1];
    int k = 0;
    int m = paramList.size();
    for (int n = 0; n < m; n++)
    {
      View localView = (View)paramList.get(n);
      LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
      int i1 = leftMargin - i;
      int i2 = rightMargin - j;
      int i3 = Math.max(0, i1);
      int i4 = Math.max(0, i2);
      i = Math.max(0, -i1);
      j = Math.max(0, -i2);
      k += i4 + (i3 + localView.getMeasuredWidth());
    }
    return k;
  }
  
  private static boolean isCustomView(View paramView)
  {
    return getLayoutParamsmViewType == 0;
  }
  
  private int layoutChildLeft(View paramView, int paramInt1, int[] paramArrayOfInt, int paramInt2)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = leftMargin - paramArrayOfInt[0];
    int j = paramInt1 + Math.max(0, i);
    paramArrayOfInt[0] = Math.max(0, -i);
    int k = getChildTop(paramView, paramInt2);
    int m = paramView.getMeasuredWidth();
    paramView.layout(j, k, j + m, k + paramView.getMeasuredHeight());
    return j + (m + rightMargin);
  }
  
  private int layoutChildRight(View paramView, int paramInt1, int[] paramArrayOfInt, int paramInt2)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = rightMargin - paramArrayOfInt[1];
    int j = paramInt1 - Math.max(0, i);
    paramArrayOfInt[1] = Math.max(0, -i);
    int k = getChildTop(paramView, paramInt2);
    int m = paramView.getMeasuredWidth();
    paramView.layout(j - m, k, j, k + paramView.getMeasuredHeight());
    return j - (m + leftMargin);
  }
  
  private int measureChildCollapseMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = leftMargin - paramArrayOfInt[0];
    int j = rightMargin - paramArrayOfInt[1];
    int k = Math.max(0, i) + Math.max(0, j);
    paramArrayOfInt[0] = Math.max(0, -i);
    paramArrayOfInt[1] = Math.max(0, -j);
    paramView.measure(getChildMeasureSpec(paramInt1, paramInt2 + (k + (getPaddingLeft() + getPaddingRight())), width), getChildMeasureSpec(paramInt3, paramInt4 + (getPaddingTop() + getPaddingBottom() + topMargin + bottomMargin), height));
    return k + paramView.getMeasuredWidth();
  }
  
  private void measureChildConstrained(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = getChildMeasureSpec(paramInt1, paramInt2 + (getPaddingLeft() + getPaddingRight() + leftMargin + rightMargin), width);
    int j = getChildMeasureSpec(paramInt3, paramInt4 + (getPaddingTop() + getPaddingBottom() + topMargin + bottomMargin), height);
    int k = View.MeasureSpec.getMode(j);
    if ((k != 1073741824) && (paramInt5 >= 0)) {
      if (k == 0) {
        break label135;
      }
    }
    label135:
    for (int m = Math.min(View.MeasureSpec.getSize(j), paramInt5);; m = paramInt5)
    {
      j = View.MeasureSpec.makeMeasureSpec(m, 1073741824);
      paramView.measure(i, j);
      return;
    }
  }
  
  private void postShowOverflowMenu()
  {
    removeCallbacks(mShowOverflowMenuRunnable);
    post(mShowOverflowMenuRunnable);
  }
  
  private void setChildVisibilityForExpandedActionView(boolean paramBoolean)
  {
    int i = getChildCount();
    int j = 0;
    if (j < i)
    {
      View localView = getChildAt(j);
      if ((getLayoutParamsmViewType != 2) && (localView != mMenuView)) {
        if (!paramBoolean) {
          break label64;
        }
      }
      label64:
      for (int k = 8;; k = 0)
      {
        localView.setVisibility(k);
        j++;
        break;
      }
    }
  }
  
  private boolean shouldCollapse()
  {
    if (!mCollapsible) {
      return false;
    }
    int i = getChildCount();
    for (int j = 0;; j++)
    {
      if (j >= i) {
        break label55;
      }
      View localView = getChildAt(j);
      if ((shouldLayout(localView)) && (localView.getMeasuredWidth() > 0) && (localView.getMeasuredHeight() > 0)) {
        break;
      }
    }
    label55:
    return true;
  }
  
  private boolean shouldLayout(View paramView)
  {
    return (paramView != null) && (paramView.getParent() == this) && (paramView.getVisibility() != 8);
  }
  
  private static Context themifyContext(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.Toolbar, paramInt, 0);
    int i = localTypedArray.getResourceId(R.styleable.Toolbar_theme, 0);
    if (i != 0) {
      paramContext = new ContextThemeWrapper(paramContext, i);
    }
    localTypedArray.recycle();
    return paramContext;
  }
  
  private void updateChildVisibilityForExpandedActionView(View paramView)
  {
    if ((getLayoutParamsmViewType != 2) && (paramView != mMenuView)) {
      if (mExpandedActionView == null) {
        break label38;
      }
    }
    label38:
    for (int i = 8;; i = 0)
    {
      paramView.setVisibility(i);
      return;
    }
  }
  
  public boolean canShowOverflowMenu()
  {
    return (getVisibility() == 0) && (mMenuView != null) && (mMenuView.isOverflowReserved());
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return (super.checkLayoutParams(paramLayoutParams)) && ((paramLayoutParams instanceof LayoutParams));
  }
  
  public void collapseActionView()
  {
    if (mExpandedMenuPresenter == null) {}
    for (MenuItemImpl localMenuItemImpl = null;; localMenuItemImpl = mExpandedMenuPresenter.mCurrentExpandedItem)
    {
      if (localMenuItemImpl != null) {
        localMenuItemImpl.collapseActionView();
      }
      return;
    }
  }
  
  public void dismissPopupMenus()
  {
    if (mMenuView != null) {
      mMenuView.dismissPopupMenus();
    }
  }
  
  protected LayoutParams generateDefaultLayoutParams()
  {
    return new LayoutParams(-2, -2);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramLayoutParams instanceof LayoutParams)) {
      return new LayoutParams((LayoutParams)paramLayoutParams);
    }
    if ((paramLayoutParams instanceof ActionBar.LayoutParams)) {
      return new LayoutParams((ActionBar.LayoutParams)paramLayoutParams);
    }
    if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams)) {
      return new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams);
    }
    return new LayoutParams(paramLayoutParams);
  }
  
  public int getContentInsetEnd()
  {
    return mContentInsets.getEnd();
  }
  
  public int getContentInsetLeft()
  {
    return mContentInsets.getLeft();
  }
  
  public int getContentInsetRight()
  {
    return mContentInsets.getRight();
  }
  
  public int getContentInsetStart()
  {
    return mContentInsets.getStart();
  }
  
  public Drawable getLogo()
  {
    if (mLogoView != null) {
      return mLogoView.getDrawable();
    }
    return null;
  }
  
  public CharSequence getLogoDescription()
  {
    if (mLogoView != null) {
      return mLogoView.getContentDescription();
    }
    return null;
  }
  
  public Menu getMenu()
  {
    ensureMenu();
    return mMenuView.getMenu();
  }
  
  @Nullable
  public CharSequence getNavigationContentDescription()
  {
    if (mNavButtonView != null) {
      return mNavButtonView.getContentDescription();
    }
    return null;
  }
  
  @Nullable
  public Drawable getNavigationIcon()
  {
    if (mNavButtonView != null) {
      return mNavButtonView.getDrawable();
    }
    return null;
  }
  
  public int getPopupTheme()
  {
    return mPopupTheme;
  }
  
  public CharSequence getSubtitle()
  {
    return mSubtitleText;
  }
  
  public CharSequence getTitle()
  {
    return mTitleText;
  }
  
  public DecorToolbar getWrapper()
  {
    if (mWrapper == null) {
      mWrapper = new ToolbarWidgetWrapper(this, true);
    }
    return mWrapper;
  }
  
  public boolean hasExpandedActionView()
  {
    return (mExpandedMenuPresenter != null) && (mExpandedMenuPresenter.mCurrentExpandedItem != null);
  }
  
  public boolean hideOverflowMenu()
  {
    return (mMenuView != null) && (mMenuView.hideOverflowMenu());
  }
  
  public void inflateMenu(int paramInt)
  {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public boolean isOverflowMenuShowPending()
  {
    return (mMenuView != null) && (mMenuView.isOverflowMenuShowPending());
  }
  
  public boolean isOverflowMenuShowing()
  {
    return (mMenuView != null) && (mMenuView.isOverflowMenuShowing());
  }
  
  public boolean isTitleTruncated()
  {
    if (mTitleTextView == null) {}
    for (;;)
    {
      return false;
      Layout localLayout = mTitleTextView.getLayout();
      if (localLayout != null)
      {
        int i = localLayout.getLineCount();
        for (int j = 0; j < i; j++) {
          if (localLayout.getEllipsisCount(j) > 0) {
            return true;
          }
        }
      }
    }
  }
  
  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    removeCallbacks(mShowOverflowMenuRunnable);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i;
    int j;
    int k;
    int m;
    int n;
    int i1;
    int i2;
    int i3;
    int i4;
    int[] arrayOfInt;
    int i5;
    label112:
    label144:
    label176:
    int i7;
    int i9;
    label280:
    label312:
    boolean bool1;
    boolean bool2;
    int i10;
    TextView localTextView1;
    label437:
    TextView localTextView2;
    label448:
    LayoutParams localLayoutParams1;
    LayoutParams localLayoutParams2;
    int i11;
    label501:
    int i40;
    label582:
    int i12;
    if (ViewCompat.getLayoutDirection(this) == 1)
    {
      i = 1;
      j = getWidth();
      k = getHeight();
      m = getPaddingLeft();
      n = getPaddingRight();
      i1 = getPaddingTop();
      i2 = getPaddingBottom();
      i3 = m;
      i4 = j - n;
      arrayOfInt = mTempMargins;
      arrayOfInt[1] = 0;
      arrayOfInt[0] = 0;
      i5 = getMinimumHeightCompat();
      if (shouldLayout(mNavButtonView))
      {
        if (i == 0) {
          break label881;
        }
        i4 = layoutChildRight(mNavButtonView, i4, arrayOfInt, i5);
      }
      if (shouldLayout(mCollapseButtonView))
      {
        if (i == 0) {
          break label900;
        }
        i4 = layoutChildRight(mCollapseButtonView, i4, arrayOfInt, i5);
      }
      if (shouldLayout(mMenuView))
      {
        if (i == 0) {
          break label919;
        }
        i3 = layoutChildLeft(mMenuView, i3, arrayOfInt, i5);
      }
      arrayOfInt[0] = Math.max(0, getContentInsetLeft() - i3);
      arrayOfInt[1] = Math.max(0, getContentInsetRight() - (j - n - i4));
      int i6 = getContentInsetLeft();
      i7 = Math.max(i3, i6);
      int i8 = j - n - getContentInsetRight();
      i9 = Math.min(i4, i8);
      if (shouldLayout(mExpandedActionView))
      {
        if (i == 0) {
          break label938;
        }
        i9 = layoutChildRight(mExpandedActionView, i9, arrayOfInt, i5);
      }
      if (shouldLayout(mLogoView))
      {
        if (i == 0) {
          break label957;
        }
        i9 = layoutChildRight(mLogoView, i9, arrayOfInt, i5);
      }
      bool1 = shouldLayout(mTitleTextView);
      bool2 = shouldLayout(mSubtitleTextView);
      i10 = 0;
      if (bool1)
      {
        LayoutParams localLayoutParams8 = (LayoutParams)mTitleTextView.getLayoutParams();
        i10 = 0 + (topMargin + mTitleTextView.getMeasuredHeight() + bottomMargin);
      }
      if (bool2)
      {
        LayoutParams localLayoutParams7 = (LayoutParams)mSubtitleTextView.getLayoutParams();
        i10 += topMargin + mSubtitleTextView.getMeasuredHeight() + bottomMargin;
      }
      if ((bool1) || (bool2))
      {
        if (!bool1) {
          break label976;
        }
        localTextView1 = mTitleTextView;
        if (!bool2) {
          break label985;
        }
        localTextView2 = mSubtitleTextView;
        localLayoutParams1 = (LayoutParams)localTextView1.getLayoutParams();
        localLayoutParams2 = (LayoutParams)localTextView2.getLayoutParams();
        if (((!bool1) || (mTitleTextView.getMeasuredWidth() <= 0)) && ((!bool2) || (mSubtitleTextView.getMeasuredWidth() <= 0))) {
          break label994;
        }
        i11 = 1;
        switch (0x70 & mGravity)
        {
        default: 
          i40 = (k - i1 - i2 - i10) / 2;
          int i41 = topMargin + mTitleMarginTop;
          if (i40 < i41)
          {
            i40 = topMargin + mTitleMarginTop;
            i12 = i1 + i40;
            label589:
            if (i == 0) {
              break label1106;
            }
            if (i11 == 0) {
              break label1100;
            }
          }
          break;
        }
      }
    }
    label881:
    label900:
    label919:
    label938:
    label957:
    label976:
    label985:
    label994:
    label1100:
    for (int i31 = mTitleMarginStart;; i31 = 0)
    {
      int i32 = i31 - arrayOfInt[1];
      i9 -= Math.max(0, i32);
      arrayOfInt[1] = Math.max(0, -i32);
      int i33 = i9;
      int i34 = i9;
      if (bool1)
      {
        LayoutParams localLayoutParams6 = (LayoutParams)mTitleTextView.getLayoutParams();
        int i38 = i33 - mTitleTextView.getMeasuredWidth();
        int i39 = i12 + mTitleTextView.getMeasuredHeight();
        mTitleTextView.layout(i38, i12, i33, i39);
        i33 = i38 - mTitleMarginEnd;
        i12 = i39 + bottomMargin;
      }
      if (bool2)
      {
        LayoutParams localLayoutParams5 = (LayoutParams)mSubtitleTextView.getLayoutParams();
        int i35 = i12 + topMargin;
        int i36 = i34 - mSubtitleTextView.getMeasuredWidth();
        int i37 = i35 + mSubtitleTextView.getMeasuredHeight();
        mSubtitleTextView.layout(i36, i35, i34, i37);
        i34 -= mTitleMarginEnd;
        (i37 + bottomMargin);
      }
      if (i11 != 0) {
        i9 = Math.min(i33, i34);
      }
      addCustomViewsWithGravity(mTempViews, 3);
      int i17 = mTempViews.size();
      for (int i18 = 0; i18 < i17; i18++) {
        i7 = layoutChildLeft((View)mTempViews.get(i18), i7, arrayOfInt, i5);
      }
      i = 0;
      break;
      i3 = layoutChildLeft(mNavButtonView, i3, arrayOfInt, i5);
      break label112;
      i3 = layoutChildLeft(mCollapseButtonView, i3, arrayOfInt, i5);
      break label144;
      i4 = layoutChildRight(mMenuView, i4, arrayOfInt, i5);
      break label176;
      i7 = layoutChildLeft(mExpandedActionView, i7, arrayOfInt, i5);
      break label280;
      i7 = layoutChildLeft(mLogoView, i7, arrayOfInt, i5);
      break label312;
      localTextView1 = mSubtitleTextView;
      break label437;
      localTextView2 = mTitleTextView;
      break label448;
      i11 = 0;
      break label501;
      i12 = getPaddingTop() + topMargin + mTitleMarginTop;
      break label589;
      int i42 = k - i2 - i10 - i40 - i1;
      if (i42 >= bottomMargin + mTitleMarginBottom) {
        break label582;
      }
      i40 = Math.max(0, i40 - (bottomMargin + mTitleMarginBottom - i42));
      break label582;
      i12 = k - i2 - bottomMargin - mTitleMarginBottom - i10;
      break label589;
    }
    label1106:
    if (i11 != 0) {}
    for (int i13 = mTitleMarginStart;; i13 = 0)
    {
      int i14 = i13 - arrayOfInt[0];
      i7 += Math.max(0, i14);
      arrayOfInt[0] = Math.max(0, -i14);
      int i15 = i7;
      int i16 = i7;
      if (bool1)
      {
        LayoutParams localLayoutParams4 = (LayoutParams)mTitleTextView.getLayoutParams();
        int i29 = i15 + mTitleTextView.getMeasuredWidth();
        int i30 = i12 + mTitleTextView.getMeasuredHeight();
        mTitleTextView.layout(i15, i12, i29, i30);
        i15 = i29 + mTitleMarginEnd;
        i12 = i30 + bottomMargin;
      }
      if (bool2)
      {
        LayoutParams localLayoutParams3 = (LayoutParams)mSubtitleTextView.getLayoutParams();
        int i26 = i12 + topMargin;
        int i27 = i16 + mSubtitleTextView.getMeasuredWidth();
        int i28 = i26 + mSubtitleTextView.getMeasuredHeight();
        mSubtitleTextView.layout(i16, i26, i27, i28);
        i16 = i27 + mTitleMarginEnd;
        (i28 + bottomMargin);
      }
      if (i11 == 0) {
        break;
      }
      i7 = Math.max(i15, i16);
      break;
    }
    addCustomViewsWithGravity(mTempViews, 5);
    int i19 = mTempViews.size();
    for (int i20 = 0; i20 < i19; i20++) {
      i9 = layoutChildRight((View)mTempViews.get(i20), i9, arrayOfInt, i5);
    }
    addCustomViewsWithGravity(mTempViews, 1);
    int i21 = getViewListMeasuredWidth(mTempViews, arrayOfInt);
    int i22 = m + (j - m - n) / 2 - i21 / 2;
    int i23 = i22 + i21;
    if (i22 < i7) {
      i22 = i7;
    }
    for (;;)
    {
      int i24 = mTempViews.size();
      for (int i25 = 0; i25 < i24; i25++) {
        i22 = layoutChildLeft((View)mTempViews.get(i25), i22, arrayOfInt, i5);
      }
      if (i23 > i9) {
        i22 -= i23 - i9;
      }
    }
    mTempViews.clear();
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int[] arrayOfInt = mTempMargins;
    int j;
    int i;
    int k;
    int m;
    int i5;
    int i7;
    label519:
    View localView;
    if (ViewUtils.isLayoutRtl(this))
    {
      j = 1;
      i = 0;
      boolean bool1 = shouldLayout(mNavButtonView);
      k = 0;
      m = 0;
      int n = 0;
      if (bool1)
      {
        measureChildConstrained(mNavButtonView, paramInt1, 0, paramInt2, 0, mMaxButtonHeight);
        n = mNavButtonView.getMeasuredWidth() + getHorizontalMargins(mNavButtonView);
        m = Math.max(0, mNavButtonView.getMeasuredHeight() + getVerticalMargins(mNavButtonView));
        k = ViewUtils.combineMeasuredStates(0, ViewCompat.getMeasuredState(mNavButtonView));
      }
      if (shouldLayout(mCollapseButtonView))
      {
        measureChildConstrained(mCollapseButtonView, paramInt1, 0, paramInt2, 0, mMaxButtonHeight);
        n = mCollapseButtonView.getMeasuredWidth() + getHorizontalMargins(mCollapseButtonView);
        int i29 = mCollapseButtonView.getMeasuredHeight() + getVerticalMargins(mCollapseButtonView);
        m = Math.max(m, i29);
        int i30 = ViewCompat.getMeasuredState(mCollapseButtonView);
        k = ViewUtils.combineMeasuredStates(k, i30);
      }
      int i1 = getContentInsetStart();
      int i2 = 0 + Math.max(i1, n);
      arrayOfInt[j] = Math.max(0, i1 - n);
      boolean bool2 = shouldLayout(mMenuView);
      int i3 = 0;
      if (bool2)
      {
        measureChildConstrained(mMenuView, paramInt1, i2, paramInt2, 0, mMaxButtonHeight);
        i3 = mMenuView.getMeasuredWidth() + getHorizontalMargins(mMenuView);
        int i27 = mMenuView.getMeasuredHeight() + getVerticalMargins(mMenuView);
        m = Math.max(m, i27);
        int i28 = ViewCompat.getMeasuredState(mMenuView);
        k = ViewUtils.combineMeasuredStates(k, i28);
      }
      int i4 = getContentInsetEnd();
      i5 = i2 + Math.max(i4, i3);
      arrayOfInt[i] = Math.max(0, i4 - i3);
      if (shouldLayout(mExpandedActionView))
      {
        i5 += measureChildCollapseMargins(mExpandedActionView, paramInt1, i5, paramInt2, 0, arrayOfInt);
        int i25 = mExpandedActionView.getMeasuredHeight() + getVerticalMargins(mExpandedActionView);
        m = Math.max(m, i25);
        int i26 = ViewCompat.getMeasuredState(mExpandedActionView);
        k = ViewUtils.combineMeasuredStates(k, i26);
      }
      if (shouldLayout(mLogoView))
      {
        i5 += measureChildCollapseMargins(mLogoView, paramInt1, i5, paramInt2, 0, arrayOfInt);
        int i23 = mLogoView.getMeasuredHeight() + getVerticalMargins(mLogoView);
        m = Math.max(m, i23);
        int i24 = ViewCompat.getMeasuredState(mLogoView);
        k = ViewUtils.combineMeasuredStates(k, i24);
      }
      int i6 = getChildCount();
      i7 = 0;
      if (i7 >= i6) {
        break label631;
      }
      localView = getChildAt(i7);
      if ((getLayoutParamsmViewType == 0) && (shouldLayout(localView))) {
        break label572;
      }
    }
    for (;;)
    {
      i7++;
      break label519;
      i = 1;
      j = 0;
      break;
      label572:
      i5 += measureChildCollapseMargins(localView, paramInt1, i5, paramInt2, 0, arrayOfInt);
      int i21 = localView.getMeasuredHeight() + getVerticalMargins(localView);
      m = Math.max(m, i21);
      int i22 = ViewCompat.getMeasuredState(localView);
      k = ViewUtils.combineMeasuredStates(k, i22);
    }
    label631:
    int i8 = mTitleMarginTop + mTitleMarginBottom;
    int i9 = mTitleMarginStart + mTitleMarginEnd;
    boolean bool3 = shouldLayout(mTitleTextView);
    int i10 = 0;
    int i11 = 0;
    if (bool3)
    {
      measureChildCollapseMargins(mTitleTextView, paramInt1, i5 + i9, paramInt2, i8, arrayOfInt);
      i11 = mTitleTextView.getMeasuredWidth() + getHorizontalMargins(mTitleTextView);
      i10 = mTitleTextView.getMeasuredHeight() + getVerticalMargins(mTitleTextView);
      int i20 = ViewCompat.getMeasuredState(mTitleTextView);
      k = ViewUtils.combineMeasuredStates(k, i20);
    }
    if (shouldLayout(mSubtitleTextView))
    {
      int i18 = measureChildCollapseMargins(mSubtitleTextView, paramInt1, i5 + i9, paramInt2, i10 + i8, arrayOfInt);
      i11 = Math.max(i11, i18);
      i10 += mSubtitleTextView.getMeasuredHeight() + getVerticalMargins(mSubtitleTextView);
      int i19 = ViewCompat.getMeasuredState(mSubtitleTextView);
      k = ViewUtils.combineMeasuredStates(k, i19);
    }
    int i12 = i5 + i11;
    int i13 = Math.max(m, i10);
    int i14 = i12 + (getPaddingLeft() + getPaddingRight());
    int i15 = i13 + (getPaddingTop() + getPaddingBottom());
    int i16 = ViewCompat.resolveSizeAndState(Math.max(i14, getSuggestedMinimumWidth()), paramInt1, 0xFF000000 & k);
    int i17 = ViewCompat.resolveSizeAndState(Math.max(i15, getSuggestedMinimumHeight()), paramInt2, k << 16);
    if (shouldCollapse()) {
      i17 = 0;
    }
    setMeasuredDimension(i16, i17);
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable)
  {
    SavedState localSavedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(localSavedState.getSuperState());
    if (mMenuView != null) {}
    for (MenuBuilder localMenuBuilder = mMenuView.peekMenu();; localMenuBuilder = null)
    {
      if ((expandedMenuItemId != 0) && (mExpandedMenuPresenter != null) && (localMenuBuilder != null))
      {
        MenuItem localMenuItem = localMenuBuilder.findItem(expandedMenuItemId);
        if (localMenuItem != null) {
          MenuItemCompat.expandActionView(localMenuItem);
        }
      }
      if (isOverflowOpen) {
        postShowOverflowMenu();
      }
      return;
    }
  }
  
  public void onRtlPropertiesChanged(int paramInt)
  {
    int i = 1;
    if (Build.VERSION.SDK_INT >= 17) {
      super.onRtlPropertiesChanged(paramInt);
    }
    RtlSpacingHelper localRtlSpacingHelper = mContentInsets;
    if (paramInt == i) {}
    for (;;)
    {
      localRtlSpacingHelper.setDirection(i);
      return;
      i = 0;
    }
  }
  
  protected Parcelable onSaveInstanceState()
  {
    SavedState localSavedState = new SavedState(super.onSaveInstanceState());
    if ((mExpandedMenuPresenter != null) && (mExpandedMenuPresenter.mCurrentExpandedItem != null)) {
      expandedMenuItemId = mExpandedMenuPresenter.mCurrentExpandedItem.getItemId();
    }
    isOverflowOpen = isOverflowMenuShowing();
    return localSavedState;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = MotionEventCompat.getActionMasked(paramMotionEvent);
    if (i == 0) {
      mEatingTouch = false;
    }
    if (!mEatingTouch)
    {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if ((i == 0) && (!bool)) {
        mEatingTouch = true;
      }
    }
    if ((i == 1) || (i == 3)) {
      mEatingTouch = false;
    }
    return true;
  }
  
  public void setCollapsible(boolean paramBoolean)
  {
    mCollapsible = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetsAbsolute(int paramInt1, int paramInt2)
  {
    mContentInsets.setAbsolute(paramInt1, paramInt2);
  }
  
  public void setContentInsetsRelative(int paramInt1, int paramInt2)
  {
    mContentInsets.setRelative(paramInt1, paramInt2);
  }
  
  public void setLogo(int paramInt)
  {
    setLogo(mTintManager.getDrawable(paramInt));
  }
  
  public void setLogo(Drawable paramDrawable)
  {
    if (paramDrawable != null)
    {
      ensureLogoView();
      if (mLogoView.getParent() == null)
      {
        addSystemView(mLogoView);
        updateChildVisibilityForExpandedActionView(mLogoView);
      }
    }
    for (;;)
    {
      if (mLogoView != null) {
        mLogoView.setImageDrawable(paramDrawable);
      }
      return;
      if ((mLogoView != null) && (mLogoView.getParent() != null)) {
        removeView(mLogoView);
      }
    }
  }
  
  public void setLogoDescription(int paramInt)
  {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence)
  {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      ensureLogoView();
    }
    if (mLogoView != null) {
      mLogoView.setContentDescription(paramCharSequence);
    }
  }
  
  public void setMenu(MenuBuilder paramMenuBuilder, ActionMenuPresenter paramActionMenuPresenter)
  {
    if ((paramMenuBuilder == null) && (mMenuView == null)) {}
    MenuBuilder localMenuBuilder;
    do
    {
      return;
      ensureMenuView();
      localMenuBuilder = mMenuView.peekMenu();
    } while (localMenuBuilder == paramMenuBuilder);
    if (localMenuBuilder != null)
    {
      localMenuBuilder.removeMenuPresenter(mOuterActionMenuPresenter);
      localMenuBuilder.removeMenuPresenter(mExpandedMenuPresenter);
    }
    if (mExpandedMenuPresenter == null) {
      mExpandedMenuPresenter = new ExpandedActionViewMenuPresenter(null);
    }
    paramActionMenuPresenter.setExpandedActionViewsExclusive(true);
    if (paramMenuBuilder != null)
    {
      paramMenuBuilder.addMenuPresenter(paramActionMenuPresenter, mPopupContext);
      paramMenuBuilder.addMenuPresenter(mExpandedMenuPresenter, mPopupContext);
    }
    for (;;)
    {
      mMenuView.setPopupTheme(mPopupTheme);
      mMenuView.setPresenter(paramActionMenuPresenter);
      mOuterActionMenuPresenter = paramActionMenuPresenter;
      return;
      paramActionMenuPresenter.initForMenu(mPopupContext, null);
      mExpandedMenuPresenter.initForMenu(mPopupContext, null);
      paramActionMenuPresenter.updateMenuView(true);
      mExpandedMenuPresenter.updateMenuView(true);
    }
  }
  
  public void setMenuCallbacks(MenuPresenter.Callback paramCallback, MenuBuilder.Callback paramCallback1)
  {
    mActionMenuPresenterCallback = paramCallback;
    mMenuBuilderCallback = paramCallback1;
  }
  
  public void setMinimumHeight(int paramInt)
  {
    mMinHeight = paramInt;
    super.setMinimumHeight(paramInt);
  }
  
  public void setNavigationContentDescription(int paramInt)
  {
    if (paramInt != 0) {}
    for (CharSequence localCharSequence = getContext().getText(paramInt);; localCharSequence = null)
    {
      setNavigationContentDescription(localCharSequence);
      return;
    }
  }
  
  public void setNavigationContentDescription(@Nullable CharSequence paramCharSequence)
  {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      ensureNavButtonView();
    }
    if (mNavButtonView != null) {
      mNavButtonView.setContentDescription(paramCharSequence);
    }
  }
  
  public void setNavigationIcon(int paramInt)
  {
    setNavigationIcon(mTintManager.getDrawable(paramInt));
  }
  
  public void setNavigationIcon(@Nullable Drawable paramDrawable)
  {
    if (paramDrawable != null)
    {
      ensureNavButtonView();
      if (mNavButtonView.getParent() == null)
      {
        addSystemView(mNavButtonView);
        updateChildVisibilityForExpandedActionView(mNavButtonView);
      }
    }
    for (;;)
    {
      if (mNavButtonView != null) {
        mNavButtonView.setImageDrawable(paramDrawable);
      }
      return;
      if ((mNavButtonView != null) && (mNavButtonView.getParent() != null)) {
        removeView(mNavButtonView);
      }
    }
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener)
  {
    ensureNavButtonView();
    mNavButtonView.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(OnMenuItemClickListener paramOnMenuItemClickListener)
  {
    mOnMenuItemClickListener = paramOnMenuItemClickListener;
  }
  
  public void setPopupTheme(int paramInt)
  {
    if (mPopupTheme != paramInt)
    {
      mPopupTheme = paramInt;
      if (paramInt == 0) {
        mPopupContext = getContext();
      }
    }
    else
    {
      return;
    }
    mPopupContext = new ContextThemeWrapper(getContext(), paramInt);
  }
  
  public void setSubtitle(int paramInt)
  {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence)
  {
    if (!TextUtils.isEmpty(paramCharSequence))
    {
      if (mSubtitleTextView == null)
      {
        Context localContext = getContext();
        mSubtitleTextView = new TextView(localContext);
        mSubtitleTextView.setSingleLine();
        mSubtitleTextView.setEllipsize(TextUtils.TruncateAt.END);
        if (mSubtitleTextAppearance != 0) {
          mSubtitleTextView.setTextAppearance(localContext, mSubtitleTextAppearance);
        }
        if (mSubtitleTextColor != 0) {
          mSubtitleTextView.setTextColor(mSubtitleTextColor);
        }
      }
      if (mSubtitleTextView.getParent() == null)
      {
        addSystemView(mSubtitleTextView);
        updateChildVisibilityForExpandedActionView(mSubtitleTextView);
      }
    }
    for (;;)
    {
      if (mSubtitleTextView != null) {
        mSubtitleTextView.setText(paramCharSequence);
      }
      mSubtitleText = paramCharSequence;
      return;
      if ((mSubtitleTextView != null) && (mSubtitleTextView.getParent() != null)) {
        removeView(mSubtitleTextView);
      }
    }
  }
  
  public void setSubtitleTextAppearance(Context paramContext, int paramInt)
  {
    mSubtitleTextAppearance = paramInt;
    if (mSubtitleTextView != null) {
      mSubtitleTextView.setTextAppearance(paramContext, paramInt);
    }
  }
  
  public void setSubtitleTextColor(int paramInt)
  {
    mSubtitleTextColor = paramInt;
    if (mSubtitleTextView != null) {
      mSubtitleTextView.setTextColor(paramInt);
    }
  }
  
  public void setTitle(int paramInt)
  {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence)
  {
    if (!TextUtils.isEmpty(paramCharSequence))
    {
      if (mTitleTextView == null)
      {
        Context localContext = getContext();
        mTitleTextView = new TextView(localContext);
        mTitleTextView.setSingleLine();
        mTitleTextView.setEllipsize(TextUtils.TruncateAt.END);
        if (mTitleTextAppearance != 0) {
          mTitleTextView.setTextAppearance(localContext, mTitleTextAppearance);
        }
        if (mTitleTextColor != 0) {
          mTitleTextView.setTextColor(mTitleTextColor);
        }
      }
      if (mTitleTextView.getParent() == null)
      {
        addSystemView(mTitleTextView);
        updateChildVisibilityForExpandedActionView(mTitleTextView);
      }
    }
    for (;;)
    {
      if (mTitleTextView != null) {
        mTitleTextView.setText(paramCharSequence);
      }
      mTitleText = paramCharSequence;
      return;
      if ((mTitleTextView != null) && (mTitleTextView.getParent() != null)) {
        removeView(mTitleTextView);
      }
    }
  }
  
  public void setTitleTextAppearance(Context paramContext, int paramInt)
  {
    mTitleTextAppearance = paramInt;
    if (mTitleTextView != null) {
      mTitleTextView.setTextAppearance(paramContext, paramInt);
    }
  }
  
  public void setTitleTextColor(int paramInt)
  {
    mTitleTextColor = paramInt;
    if (mTitleTextView != null) {
      mTitleTextView.setTextColor(paramInt);
    }
  }
  
  public boolean showOverflowMenu()
  {
    return (mMenuView != null) && (mMenuView.showOverflowMenu());
  }
  
  private class ExpandedActionViewMenuPresenter
    implements MenuPresenter
  {
    MenuItemImpl mCurrentExpandedItem;
    MenuBuilder mMenu;
    
    private ExpandedActionViewMenuPresenter() {}
    
    public boolean collapseItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl)
    {
      if ((mExpandedActionView instanceof CollapsibleActionView)) {
        ((CollapsibleActionView)mExpandedActionView).onActionViewCollapsed();
      }
      removeView(mExpandedActionView);
      removeView(mCollapseButtonView);
      mExpandedActionView = null;
      Toolbar.this.setChildVisibilityForExpandedActionView(false);
      mCurrentExpandedItem = null;
      requestLayout();
      paramMenuItemImpl.setActionViewExpanded(false);
      return true;
    }
    
    public boolean expandItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl)
    {
      Toolbar.this.ensureCollapseButtonView();
      if (mCollapseButtonView.getParent() != Toolbar.this) {
        addView(mCollapseButtonView);
      }
      mExpandedActionView = paramMenuItemImpl.getActionView();
      mCurrentExpandedItem = paramMenuItemImpl;
      if (mExpandedActionView.getParent() != Toolbar.this)
      {
        Toolbar.LayoutParams localLayoutParams = generateDefaultLayoutParams();
        gravity = (0x800003 | 0x70 & mButtonGravity);
        mViewType = 2;
        mExpandedActionView.setLayoutParams(localLayoutParams);
        addView(mExpandedActionView);
      }
      Toolbar.this.setChildVisibilityForExpandedActionView(true);
      requestLayout();
      paramMenuItemImpl.setActionViewExpanded(true);
      if ((mExpandedActionView instanceof CollapsibleActionView)) {
        ((CollapsibleActionView)mExpandedActionView).onActionViewExpanded();
      }
      return true;
    }
    
    public boolean flagActionItems()
    {
      return false;
    }
    
    public int getId()
    {
      return 0;
    }
    
    public MenuView getMenuView(ViewGroup paramViewGroup)
    {
      return null;
    }
    
    public void initForMenu(Context paramContext, MenuBuilder paramMenuBuilder)
    {
      if ((mMenu != null) && (mCurrentExpandedItem != null)) {
        mMenu.collapseItemActionView(mCurrentExpandedItem);
      }
      mMenu = paramMenuBuilder;
    }
    
    public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {}
    
    public void onRestoreInstanceState(Parcelable paramParcelable) {}
    
    public Parcelable onSaveInstanceState()
    {
      return null;
    }
    
    public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
    {
      return false;
    }
    
    public void setCallback(MenuPresenter.Callback paramCallback) {}
    
    public void updateMenuView(boolean paramBoolean)
    {
      int i;
      int j;
      if (mCurrentExpandedItem != null)
      {
        MenuBuilder localMenuBuilder = mMenu;
        i = 0;
        if (localMenuBuilder != null) {
          j = mMenu.size();
        }
      }
      for (int k = 0;; k++)
      {
        i = 0;
        if (k < j)
        {
          if (mMenu.getItem(k) == mCurrentExpandedItem) {
            i = 1;
          }
        }
        else
        {
          if (i == 0) {
            collapseItemActionView(mMenu, mCurrentExpandedItem);
          }
          return;
        }
      }
    }
  }
  
  public static class LayoutParams
    extends ActionBar.LayoutParams
  {
    static final int CUSTOM = 0;
    static final int EXPANDED = 2;
    static final int SYSTEM = 1;
    int mViewType = 0;
    
    public LayoutParams(int paramInt)
    {
      this(-2, -1, paramInt);
    }
    
    public LayoutParams(int paramInt1, int paramInt2)
    {
      super(paramInt2);
      gravity = 8388627;
    }
    
    public LayoutParams(int paramInt1, int paramInt2, int paramInt3)
    {
      super(paramInt2);
      gravity = paramInt3;
    }
    
    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
    }
    
    public LayoutParams(ActionBar.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public LayoutParams(LayoutParams paramLayoutParams)
    {
      super();
      mViewType = mViewType;
    }
    
    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
      copyMarginsFromCompat(paramMarginLayoutParams);
    }
    
    void copyMarginsFromCompat(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      leftMargin = leftMargin;
      topMargin = topMargin;
      rightMargin = rightMargin;
      bottomMargin = bottomMargin;
    }
  }
  
  public static abstract interface OnMenuItemClickListener
  {
    public abstract boolean onMenuItemClick(MenuItem paramMenuItem);
  }
  
  static class SavedState
    extends View.BaseSavedState
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator()
    {
      public Toolbar.SavedState createFromParcel(Parcel paramAnonymousParcel)
      {
        return new Toolbar.SavedState(paramAnonymousParcel);
      }
      
      public Toolbar.SavedState[] newArray(int paramAnonymousInt)
      {
        return new Toolbar.SavedState[paramAnonymousInt];
      }
    };
    public int expandedMenuItemId;
    public boolean isOverflowOpen;
    
    public SavedState(Parcel paramParcel)
    {
      super();
      expandedMenuItemId = paramParcel.readInt();
      if (paramParcel.readInt() != 0) {}
      for (boolean bool = true;; bool = false)
      {
        isOverflowOpen = bool;
        return;
      }
    }
    
    public SavedState(Parcelable paramParcelable)
    {
      super();
    }
    
    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeInt(expandedMenuItemId);
      if (isOverflowOpen) {}
      for (int i = 1;; i = 0)
      {
        paramParcel.writeInt(i);
        return;
      }
    }
  }
}
