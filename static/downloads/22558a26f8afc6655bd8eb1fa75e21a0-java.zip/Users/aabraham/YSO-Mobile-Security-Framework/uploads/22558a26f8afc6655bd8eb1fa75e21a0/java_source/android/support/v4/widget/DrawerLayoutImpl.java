package android.support.v4.widget;

abstract interface DrawerLayoutImpl
{
  public abstract void setChildInsets(Object paramObject, boolean paramBoolean);
}
